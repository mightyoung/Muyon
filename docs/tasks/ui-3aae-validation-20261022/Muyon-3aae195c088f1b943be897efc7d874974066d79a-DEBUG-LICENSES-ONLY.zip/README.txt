Muyon DEBUG 候选；固定已合入功能源码 3aae195c088f1b943be897efc7d874974066d79a (PR104/PR105).
APK 430153964 bytes; SHA256 2f3b67f53e25085aecce68a433b96921691d3b187813544fc761f0f55113b8bd
ABI arm64-v8a/x86_64; minSdk26;targetSdk36;version0.1.0; Android debug signer.
普通ProductService verified=false；debug Bot fixture许可不等于产品门槛开放。
不含真实provider/搜索/推理/物理ARM64/生产Reader授权链路验收。
当前构建、真实页面及隔离组件测试的精确结果见同批验证报告，不将测试fixture当正式业务。
APK内11份完整notice原字节见licenses/，生成字典归属及上游声明来源修正见MODEL-LICENSE-NOTICE.md。
