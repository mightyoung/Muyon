from pathlib import Path
import sys,json,hashlib,zipfile,subprocess,re,os
root=Path('/workspace/batch4/integration');base=Path('/workspace/batch4/evidence/android/final-3f1be180');out=Path('/workspace/batch4/evidence/android-review');remote=Path('/workspace/batch4/evidence/ci/f2-android/downloads');F='3f1be180bb009a91e659c113ba5b1916e5360332'
sys.path.insert(0,str(root/'experiments/redesign/android-rust-bridge-lab/checks'));from android_gate import api24_imports,TARGETS;from elf_check import inspect;from full_evidence import jvm_full,panic_full,rust_full;from linux_gate import UNIT,INTEGRATION
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();r={}
for scope,linux in [('local',base/'artifacts/linux'),('ci',remote/'linux')]:
 v=json.loads((linux/'verdict.json').read_text());r[scope+'_strict_linux_original']=v['source_sha']==F and v['classification']=='GREEN' and jvm_full((linux/'behavior.log').read_text(),F,v['library_sha256']) and panic_full((linux/'panic.log').read_text(),F,v['panic_library_sha256']) and rust_full((linux/'rust-full.log').read_text(),UNIT,INTEGRATION) and (linux/'load-negative.log').read_text()=='ANDROID_BRIDGE_JVM_PASS missing_native_load_stays_unavailable\n'
 source=json.loads((linux/'source-inputs-before.json').read_text());r[scope+'_linux_source_inputs']=source==json.loads((linux/'source-inputs-after.json').read_text()) and all(sha(root/k)==v for k,v in source.items())
orig=(root/'experiments/redesign/rust-agent-host-lab/core/src/service_controller.rs').read_text();summary=json.loads((base/'service-inverses/summary.json').read_text());changes={
'dedup':('.find(|s| intent_of(s).request_id == req.request_id)','.find(|s| false && intent_of(s).request_id == req.request_id)'),
'epoch':('if r.expected_service_epoch != self.meta.service_epoch {','if false && r.expected_service_epoch != self.meta.service_epoch {'),
'join_slot':('if PROCESS_OCCUPIED\n            .compare_exchange','if false && PROCESS_OCCUPIED\n            .compare_exchange')}
for row in summary['rows']:
 before,after=changes[row['name']];expected=hashlib.sha256(orig.replace(before,after).encode()).hexdigest();build=base/'service-inverses'/row['name']/'build.log';rec=json.loads(build.with_suffix('.log.json').read_text());r[row['name']+'_exact_unique_mutation_source']=orig.count(before)==1 and expected==row['mutation_source_sha256'];r[row['name']+'_real_compiled_release_build']=rec['exit_code']==0 and 'Compiling muyon-rust-agent-host-lab' in build.read_text() and 'Finished `release` profile' in build.read_text()
ordinary=json.loads((base/'ordinary/verdict.json').read_text());r['ordinary_F2_green_no_bridge']=ordinary['source_sha']==F and ordinary['classification']=='GREEN' and ordinary['source_inputs_unchanged'] and ordinary['native_inputs_supplied'] is False
for name,meta in ordinary['artifacts'].items():
 p=base/'ordinary'/name
 with zipfile.ZipFile(p) as z:natives={e:hashlib.sha256(z.read(e)).hexdigest() for e in z.namelist() if e.startswith('lib/') and e.endswith('.so')}
 r['ordinary_'+name+'_actual_sha_no_bridge']=sha(p)==meta['sha256'] and natives==meta['native_entries'] and not any('libmuyon_android_contract_bridge.so' in e for e in natives)
private=(base/'service-private-runner.log').read_text();counts=re.findall(r'^test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;',private,re.M);r['private_exact_5_targets_13']=counts==['4','4','1','2','2'] and len(re.findall(r'^test \S+ \.\.\. ok$',private,re.M))==13
# Independent readelf strong-import revalidation against installed exact API24 NDK stubs.
ndk=Path('/workspace/batch4/tools/android/sdk/ndk/28.2.13676358');readelf=ndk/'toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-readelf';api={}
for scope,art,paths in [('local',base,{'arm64-v8a':'artifacts/arm64-v8a','x86_64':'artifacts/x86_64'}),('ci',remote,{'arm64-v8a':'arm64','x86_64':'x86'})]:
 for abi,rel in paths.items():
  d=out/'f2-api24'/scope/abi;d.mkdir(parents=True,exist_ok=True);lib=art/rel/'libmuyon_android_contract_bridge.so';info=inspect(lib.read_bytes(),abi);got=api24_imports(lib,info,TARGETS[abi][0],ndk,readelf,d,dict(os.environ),'rust');m=json.loads((art/rel/'manifest.json').read_text());r[scope+'_'+abi+'_independent_API24_imports']=got==m['rust_elf']['api24_import_compatibility'];api[scope+'_'+abi]=got
for abi in ['arm64-v8a','x86_64']:
 d=out/'f2-api24/jna'/abi;d.mkdir(parents=True,exist_ok=True);lib=d/'libjnidispatch.so'
 with zipfile.ZipFile(remote/'package/app-debug.apk') as z:lib.write_bytes(z.read('lib/'+abi+'/libjnidispatch.so'))
 info=inspect(lib.read_bytes(),abi,rust=False);got=api24_imports(lib,info,TARGETS[abi][0],ndk,readelf,d,dict(os.environ),'jna');m=json.loads((remote/('arm64' if abi=='arm64-v8a' else 'x86')/'manifest.json').read_text());r['jna_'+abi+'_independent_API24_imports']=got==m['jna_elf']['api24_import_compatibility'];api['jna_'+abi]=got
r['three_actual_mutants_distinct_from_baseline']=len({sha(base/'artifacts/linux/shipping/libmuyon_android_contract_bridge.so'),*(sha(base/'service-inverses'/name/'libmuyon_android_contract_bridge.so') for name in ['dedup','epoch','join_slot'])})==4
result={'source_sha':F,'checks':r,'all_checks_pass':all(r.values()),'API24':api};(out/'F2-EXTRA-REVIEW.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'all_checks_pass':all(r.values()),'checks':r},indent=2))
