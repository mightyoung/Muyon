from pathlib import Path
import hashlib,json,sys,re,subprocess,zipfile,struct
F='3f1be180bb009a91e659c113ba5b1916e5360332'
root=Path('/workspace/batch4/integration');base=Path('/workspace/batch4/evidence/android/final-3f1be180');out=Path('/workspace/batch4/evidence/android-review')
sys.path.insert(0,str(root/'docs/tasks/leaderb-batch4-android-validation-20261018'));sys.path.insert(0,str(root/'experiments/redesign/android-rust-bridge-lab/checks'))
from same_source_shipping_inverses import classify
from verify_shipping_records import load_record,verify_record
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
results={'source_sha':F,'pending':[],'checks':{}}
def check(name,value):
 results['checks'][name]=value
 if value is not True:print('FAILED',name,value)
for rel in ['suite-verdict.json','artifacts/linux/verdict.json','service/verdict.json','service-inverses/summary.json','package/verdict.json','ordinary/verdict.json']:
 if not (base/rel).exists():results['pending'].append(rel)
logs=[]
for path in base.rglob('*.log.json'):
 r=json.loads(path.read_text());raw=path.with_suffix('');logs.append({'path':str(path.relative_to(base)),'hash_ok':sha(raw)==r['raw_sha256'],'clean':not r['timed_out'] and not r['forced_owned_group_cleanup'] and r['live_after_cleanup']==[],'exit':r['exit_code']})
check('all_completed_process_record_raw_hashes',all(r['hash_ok'] for r in logs));check('all_completed_process_records_clean',all(r['clean'] for r in logs));results['process_records']=logs
if (base/'service/verdict.json').exists():
 service=json.loads((base/'service/verdict.json').read_text());linux=json.loads((base/'artifacts/linux/verdict.json').read_text());binding=base/'artifacts/linux/jvm/com/mightyoung/muyon/androidbridge/muyon_android_contract_bridge.kt';lib=base/'artifacts/linux/shipping/libmuyon_android_contract_bridge.so';jar=base/'service/probe.jar'
 check('service_green_exact_F',service['classification']=='GREEN' and service['source_sha']==linux['source_sha']==F)
 check('service_linux_actual_library_hash',sha(lib)==service['library_sha256']==linux['library_sha256'])
 check('service_linux_actual_binding_hash',sha(binding)==service['jvm_binding_sha256']==linux['jvm_binding_sha256'])
 check('service_actual_probe_jar_hash',sha(jar)==service['probe_sha256'])
 check('service_frozen_probe_source_hash',sha(base/'verification/ShippingServiceProbe.kt')==service['probe_source_sha256']=='fd89033de3630a2805b419fd5f420e303912af2df467c9073a2bc3f7d3a11db2')
 if (base/'service/baseline/runs.tsv').exists():
  rows=[line.split('\t') for line in (base/'service/baseline/runs.tsv').read_text().splitlines()]
  for row in rows:verify_record(row,load_record(row),F)
  check('independent_four_variant_durable_reverification',len(rows)==4 and len({r[0] for r in rows})==4)
if (base/'service-inverses/summary.json').exists():
 summary=json.loads((base/'service-inverses/summary.json').read_text());check('inverse_summary_exact_F_three_accepted',summary['source_sha']==F and summary['accepted'] is True and len(summary['rows'])==3)
 for row in summary['rows']:
  d=base/'service-inverses'/row['name'];lib=d/'libmuyon_android_contract_bridge.so'
  check(row['name']+'_actual_mutant_library_hash',sha(lib)==row['mutant_library_sha256'])
  for label in ['baseline','mutant']:
   raw=(d/(label+'.log')).read_text();rec=json.loads((d/(label+'.log.json')).read_text());check(row['name']+'_'+label+'_independent_classifier',classify(raw,rec,row['marker'] if label=='mutant' else None))
   mapped=re.findall(r'^SERVICE_SHIPPING_MAPPED source=([0-9a-f]{40}) sha256=([0-9a-f]{64})$',raw,re.M)
   actual=sha(lib if label=='mutant' else base/'artifacts/linux/shipping/libmuyon_android_contract_bridge.so')
   check(row['name']+'_'+label+'_mapped_exact_F_actual_so',mapped==[(F,actual)])
if (base/'suite-verdict.json').exists():
 verdict=json.loads((base/'suite-verdict.json').read_text());check('suite_exact_F_accepted',verdict['source_sha']==F and verdict['accepted'] is True and verdict['classification']=='GREEN')
results['complete']=not results['pending'];results['all_checks_pass']=all(x is True for x in results['checks'].values());(out/'F2-FINAL-ARTIFACT-REVIEW.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({k:v for k,v in results.items() if k!='process_records'},indent=2))
