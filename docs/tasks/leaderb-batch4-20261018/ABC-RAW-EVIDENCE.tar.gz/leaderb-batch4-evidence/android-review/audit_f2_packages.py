from pathlib import Path
import sys,json,hashlib,zipfile,struct,subprocess,re,xml.etree.ElementTree as ET
F='3f1be180bb009a91e659c113ba5b1916e5360332';OLD='a3ee7df596b0375aa9f3e6ff4c7651efd5f778a0'
root=Path('/workspace/batch4/integration');out=Path('/workspace/batch4/evidence/android-review');local=Path('/workspace/batch4/evidence/android/final-3f1be180');remote=Path('/workspace/batch4/evidence/ci/f2-android/downloads')
sys.path.insert(0,str(root/'experiments/redesign/android-rust-bridge-lab/checks'));from elf_check import inspect
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();results={'source_sha':F,'checks':{},'packages':{},'native':{},'limitations':[]}
def ck(n,b):
 results['checks'][n]=bool(b)
 if not b: print('FAIL',n)
for scope,base,paths in [('local',local,{'arm64-v8a':'artifacts/arm64-v8a','x86_64':'artifacts/x86_64'}),('ci',remote,{'arm64-v8a':'arm64','x86_64':'x86'})]:
 for abi,rel in paths.items():
  d=base/rel;m=json.loads((d/'manifest.json').read_text());lib=d/'libmuyon_android_contract_bridge.so';body=lib.read_bytes();actual=inspect(body,abi);inputs=json.loads((d/'source-inputs.json').read_text());row={'actual_so_sha256':sha(lib),'F2_identity_count':body.count(F.encode()),'old_F_identity_count':body.count(OLD.encode()),'load_alignments':actual['load_alignments']};results['native'][scope+'_'+abi]=row
  ck(scope+'_'+abi+'_manifest_identity',m['classification']=='GREEN' and m['source_sha']==m['build_identity']==F and m['source_inputs_unchanged'] and m['min_api']==24)
  ck(scope+'_'+abi+'_actual_so_and_elf',sha(lib)==m['library_sha256'] and actual=={k:v for k,v in m['rust_elf'].items() if k!='api24_import_compatibility'})
  ck(scope+'_'+abi+'_embedded_current_not_old',row['F2_identity_count']>0 and row['old_F_identity_count']==0)
  ck(scope+'_'+abi+'_source_hashes',all(sha(root/k)==v for k,v in inputs.items()))
 p=base/'package';m=json.loads((p/'verdict.json').read_text());ck(scope+'_package_green_F2',m['classification']=='GREEN' and m['source_sha']==F and m['source_inputs_unchanged'])
 ck(scope+'_bridge_input_hash',sha(p/'bridge-inputs/bridge-inputs.json')==m['bridge_inputs_sha256']);bridge=json.loads((p/'bridge-inputs/bridge-inputs.json').read_text());ck(scope+'_bridge_manifest_F2',bridge['source_sha']==bridge['build_identity']==F)
 pkg={'pass_lines':sum(l.startswith('PASS ') for l in (p/'required-gradle.log').read_text().splitlines()),'apks':{}};ck(scope+'_actual_state_163',pkg['pass_lines']==163)
 for name,key in [('app-debug.apk','apk_sha256'),('app-debug-androidTest.apk','test_apk_sha256')]:
  apk=p/name;ck(scope+'_'+name+'_sha',sha(apk)==m[key]);raw=apk.read_bytes();natives={};offsets={}
  with zipfile.ZipFile(apk) as z:
   for e in z.infolist():
    if e.filename.startswith('lib/') and e.filename.endswith('.so'):
     data=z.read(e);natives[e.filename]=hashlib.sha256(data).hexdigest();fields=struct.unpack_from('<4s5H3I2H',raw,e.header_offset);offset=e.header_offset+30+fields[-2]+fields[-1];offsets[e.filename]=offset
     ck(scope+'_'+name+'_'+e.filename+'_stored_aligned',e.compress_type==zipfile.ZIP_STORED and offset%16384==0)
     phoff=struct.unpack_from('<Q',data,32)[0];phsize,phnum=struct.unpack_from('<HH',data,54);aligns=[struct.unpack_from('<Q',data,phoff+i*phsize+48)[0] for i in range(phnum) if struct.unpack_from('<I',data,phoff+i*phsize)[0]==1];ck(scope+'_'+name+'_'+e.filename+'_ELF_align',bool(aligns) and all(n>=16384 and n%16384==0 for n in aligns))
   if name=='app-debug.apk':
    ck(scope+'_apk_native_hash_inventory',natives==m['apk_native_entries'] and len(natives)==6)
    for abi,rel in paths.items():ck(scope+'_apk_rust_matches_producer_'+abi,natives['lib/'+abi+'/libmuyon_android_contract_bridge.so']==sha(base/rel/'libmuyon_android_contract_bridge.so'))
    ck(scope+'_apk_dex_F2',any(F.encode() in z.read(e) for e in z.namelist() if e.endswith('.dex')))
  log=out/(scope+'-'+name+'-zipalign.log');proc=subprocess.run(['/workspace/batch4/tools/android/sdk/build-tools/35.0.0/zipalign','-c','-P','16','4',str(apk)],capture_output=True,text=True);log.write_text(proc.stdout+proc.stderr);ck(scope+'_'+name+'_independent_zipalign',proc.returncode==0)
  pkg['apks'][name]={'sha256':sha(apk),'native_entries':natives,'native_offsets':offsets}
 results['packages'][scope]=pkg
 retained=p/'build-evidence'
 if retained.exists():
  inv=json.loads((retained/'inventory.json').read_text());ck(scope+'_retained_lint_aidl_hashes',all(sha(retained/r['path'])==r['sha256'] for r in inv))
  lint=ET.parse(retained/'reports/lint-results-debug.xml');issues=lint.findall('issue');pkg['lint_severity_counts']={sev:sum(i.attrib.get('severity')==sev for i in issues) for sev in ['Error','Warning','Fatal']};ck(scope+'_lint_zero_errors',not any(i.attrib.get('severity') in ['Error','Fatal'] for i in issues))
  aidl=retained/'generated/aidl_source_output_dir/debug/out/com/mightyoung/muyon/androidlab/agentipc/IAgentRuntime.java';text=aidl.read_text();ck(scope+'_actual_generated_AIDL',all(s in text for s in ['interface IAgentRuntime','class Stub','class Proxy','android.os.Binder']))
 else:results['limitations'].append(scope+' artifact contains task log lintDebug and compileDebugAidl, but no retained lint report/generated AIDL Java; local retained outputs independently checked.')
# Inspect every downloaded command record without trusting summary labels.
rows=[]
for p in remote.rglob('*.log.json'):
 r=json.loads(p.read_text());rows.append({'path':str(p.relative_to(remote)),'raw_hash_matches':sha(p.with_suffix(''))==r['raw_sha256'],'clean':r['timed_out'] is False and r['forced_owned_group_cleanup'] is False and r['live_after_cleanup']==[],'exit':r['exit_code']})
ck('ci_all_process_raw_hashes',all(r['raw_hash_matches'] for r in rows));ck('ci_all_processes_clean_zero',all(r['clean'] and r['exit']==0 for r in rows));results['ci_process_records']=rows
results['all_checks_pass']=all(results['checks'].values());(out/'F2-PACKAGE-NATIVE-CI-REVIEW.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({'all_checks_pass':results['all_checks_pass'],'checks':len(results['checks']),'packages':{k:{'pass_lines':v['pass_lines'],'lint':v.get('lint_severity_counts')} for k,v in results['packages'].items()},'limitations':results['limitations']},indent=2))
