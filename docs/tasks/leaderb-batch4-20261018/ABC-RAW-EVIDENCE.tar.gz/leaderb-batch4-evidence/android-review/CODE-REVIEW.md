# Android Batch4 independent read-only code review

Reviewed patch: `277da530187368d677e8de645294f8d3504f2f4e` (9 verification-only files), as initially integrated. No source edits, Rust/Gradle execution, commits or push performed. This is an initial code review; final candidate and actual output review remain pending.

## Findings

1. **Important — stale Batch3 source prevents current candidate Service GREEN.** `test_verify_shipping_records.py:8` hardcodes `2fbdc13efd84cabf04623775f87e762cd0d08c11`. `run-shipping.py:20` invokes those controls against current-HEAD records. The positive sibling and later-stage negative controls fail at `durable_identity_binding`. Reproduced by loading a retained old fixture read-only, changing only summary/index source identity in memory to current HEAD, verifying it passes with current source and fails with hardcoded old source. See `lightweight-results.json`. Must derive independently specified current source, not relabel old records.

2. **Important — suite reports exit0 despite failed/missing stages.** `run-suite.py` records individual stage exits but does not aggregate and exit nonzero; missing JAR/library skips required inverse stage. Root independently found this and has requested repair. Require exact complete stage inventory, accepted per-stage verdicts and aggregate failure propagation. Product input changes in shipping/ordinary finally blocks currently record false but do not invalidate GREEN or exit nonzero.

3. **Validation gap — contract controls omitted from suite.** `test_same_source_contract.py` has 9 passing tests, but suite discovers only existing `checks/test_*.py`; shipping discovers only record controls. Include the new contract/classifier tests in the actual suite.

4. **Provenance gap — generated binding cross-check incomplete.** Inverse runner checks file hash against Service binding hash but ignores Linux producer binding hash; also frozen probe source file is checked without comparing Service producer `probe_source_sha256`. Cross-check both producer binding identities and probe source identity to detect changes between stages. Sent to implementation agent.

## Positive checks and scope

- Probe source is byte-identical to retained Batch3 source; SHA256 `fd89033de3630a2805b419fd5f420e303912af2df467c9073a2bc3f7d3a11db2`. Durable verifier is likewise byte-identical.
- Probe checks current source format, real bridge buildIdentity/protocol, Linux mapped native library, reply metadata, completed original task/receipt, visibility, stale epoch, duplicate and conflict semantics, reconciliation byte preservation, process slot until join, and restore behavior for each of four variants.
- Inverse runner archives exact current clean HEAD, checks source-input manifest and same-run library/JAR hashes, applies each unique Rust source mutation to the original controller text, invokes actual cargo release library build, then executes a fresh paired baseline and mutant JVM probe.
- Classifier requires baseline exit0/four ordered pass variants/all-pass marker; mutants require exact intended main-thread assertion and exit1; timeout, forced owned cleanup, survivor, unrelated failure and compilation text fail. Nine Python contract controls passed independently (`contract-controls.log`, exit0).
- Durable oracle checks four variants, exactly one original durable run and receipt, original task/attempt/binding, fixed fixture mappings and exact safe second payload projection. It explicitly does not observe first actual payload or exact handler count.
- All reviewed probe/README/oracle results preserve Linux/JVM scope. Android ART/Binder/UID/permissions/fsync/kill/rebind/device/emulator remain NOT_RUN.
- Fixed Batch3 handoff `49d3f6030c4d3464d66b4b6421e5cc416aa36133` confirms old exact2f evidence did not execute the new3 inverses and cannot certify the final Batch4 candidate.

## Remaining work

Re-review remediation commits and frozen final candidate. Independently inspect actual manifests, source/binding/JAR/SO hashes, baseline/three mutant process records and raw log hashes, build logs, seven record controls, package APK/native entries/lint/AIDL preservation, and ordinary APK native absence. No final compiled acceptance is claimed by this initial report.

## Remediation review — a11fbc3cab9441fdf7e688476b41e94e9b1e84ce

All four initial findings are addressed by integrated A corrections b40ff8a5/a4b3fbcf. No remaining Important code finding in the reviewed scope.

- Suite now uses shared `suite_result.outcome`, exact ten-stage inventory and final nonzero exit when any stage fails, inverse is missing, a stage repeats or inventory differs. Actual subprocess controls verify complete success, exit7 failure, omitted inverse and duplicate rows.
- `verification-controls` is a required stage and its actual discovery `test_s*.py` ran all 13 contract/aggregate tests; exit0 retained in `remediation-controls.log` / `.exit`.
- Record controls require explicit `MUYON_SERVICE_SOURCE` and compare with `git rev-parse HEAD` from explicit source root before loading fixtures. No old product hash remains in that control.
- Shipping and ordinary convert changed tracked inputs to INVALID and raise `source_inputs_changed`. Independently exercised both actual runner files with isolated mocked producers/artifacts and injected before/after input mismatch: both wrote INVALID/false then raised. These are Python negative controls only, not compiled/native acceptance. Results: `remediation-results.json`.
- Inverse binding hash must now equal both Service and Linux producer binding hashes; Service probe source hash must match the independently frozen actual source file.
- Package lint output and generated AIDL source are copied with a hash inventory before ordinary clean. Actual presence/content must still be checked in final evidence; code review does not substitute for that.

Final immutable execution SHA and fresh compilation evidence remain pending. This report approves corrected verification code within scope, not the candidate's compiled outcomes.

## Exact F original evidence review in progress

Candidate F: `a3ee7df596b0375aa9f3e6ff4c7651efd5f778a0`. A worktree and integration report that exact clean HEAD.

R1 `evidence/android/final-a3ee7df5` is **INVALID**, total runner exit1. Original behavior log SHA matches its process record and actual library SHA matches the manifest. The Java child itself exited0 without timeout/cleanup/survivors. Unchanged stock `jvm_full` rejects its original seven lines because a `JAVA_TOOL_OPTIONS` launcher message precedes the required six lines. A diagnostic-only in-memory removal of that single line makes the unchanged checker accept; this is evidence about cause, not acceptance and does not alter the original raw. Service then refuses Linux INVALID, package refuses `linux_provenance`, ordinary cannot find Gradle because packaging never installed it, and required inverse is explicitly missing in aggregate INVALID. No checker/source/raw-log relaxation was used. See `F-R1-AND-R2-NATIVE-REVIEW.json`.

Fresh R2 `evidence/android/final-a3ee7df5-r2` native arm64-v8a and x86_64 manifests are GREEN with exact F source/build identity, API24, no missing strong imports and 16KiB Rust/JNA LOAD alignments. Actual Rust SO SHA and independently reparsed ELF match each manifest. All 358 source inputs per ABI match current F bytes. Linux and Service subsequently wrote GREEN with actual shared library and binding cross-hashes matching both producers, actual JAR hash and independently frozen source hash. Re-reading and verifying the actual same-run four-variant durable records against F passed; original seven record controls say OK.

Compiled inverse/package/ordinary/final ten-stage suite review is still pending. `F-FINAL-ARTIFACT-REVIEW.json` records only completed checks and missing artifacts, so no final acceptance is implied. Android ART/Binder/UID/permissions/fsync/kill/rebind/device/emulator remain NOT_RUN.

### F R2 interrupted — no complete acceptance

Parent confirmed R2 scheduler was deliberately stopped after Service completed to address a separately discovered workflow selector issue and freeze a new candidate F2. R2 top scheduler exit143 is interruption, not failure-free completion. Service child exit0 did not become a top-level `service-runner.exit` before termination. Existing F component checks remain component-only; F did not complete the ten-stage suite and **must not be described as PASS**. No inverse, package or ordinary acceptance can be inferred from this attempt. Await F2 and a new full evidence base; do not graft F artifacts to F2.
