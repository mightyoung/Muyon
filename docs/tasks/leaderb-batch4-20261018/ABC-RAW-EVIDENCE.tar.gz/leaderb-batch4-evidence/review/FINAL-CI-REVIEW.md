# 正式最终候选CI：独立原件审计

结论：**CI范围 C0，通过。** 下载的实际原件支持F自身的正式Rust/进程/反向门禁通过，不再只是Batch3外置runner或其他SHA绿色。无Critical/Important发现。该结论尚不认证A的Android/Service/JNI/package r2，亦不代替最终整套合入判断。

固定候选 `a3ee7df596b0375aa9f3e6ff4c7651efd5f778a0`，tree `358469bad933f71eca100ef1d4833685eaa3fd3f`；[CI39096739872](https://github.com/mightyoung/Muyon/actions/runs/39096739872)。CI终态completed/success及五job/所有steps成功由父/root API核查；本review独立审计恢复的下载原件，没有重新查询API、没有新构建、没有变更源码或远端。

证据根 `/workspace/batch4/evidence/ci/downloads/{core,plugin,host,native,http}/`。下载恢复方式由父/root执行；不把最初blob403下载失败写成测试失败或缺失原件。927个实际文件已独立SHA封存于 `FINAL-CI-RAW-SHA256.json`。

## 实际审计结果

| 范围 | 独立核验 |
|---|---|
| 五个gate | 每个gate-verdict exactF/tree、command exit0、source_inputs_unchanged true；五份source-manifest完全同hash，2751个tracked文件逐项与本地clean F字节一致 |
| Classifier | 每job实际classifier.log含37个方法、Ran37/OK；不把synthetic classifier positive当产品运行 |
| Rust full | core115/plugin22/host59的behavior.log raw SHA与verdict相符；用F实际full.rust combined重新逐group、逐name、status与summary分类均通过，非只比count |
| core物理层 | process26、wire_process18、test_harness6、test_wire_harness7，实际日志逐方法重分类，raw SHA与各verdict相符 |
| broad legacy17 | 17身份及compiled/退出码核验；16Rust真实日志有编译结束、目标FAILED、return101；第17独立物理目标return1、实际RUST_WIRE_ARGS_ACK_OBSERVED和`AssertionError: 1 != 0 ... PRETERMINAL_PHYSICAL_EFFECT`、单失败，无setup timeout |
| precise legacy16 | 身份/target/needles与F CONTRACTS逐项一致；每baseline exit0且精确目标ok，baseline/mutant rawhash相符；每mutant101，无timeout/forced cleanup/live residual，F accepted()重新判exact panic target/source行/语义均通过 |
| native3 | summary source=F、fixture/host/source_before/source_after hash匹配F；三baseline+三mutant分别重跑F oracle，目标/计数/数值/marker/reach/cleanup全部通过；编译记录exit0且自然cleanup，rawhash相符；不是靠summary KILLED标签 |
| HTTP7 | 七name/target/needles与F MUTANTS一致；逐baseline0、exact目标ok、rawhash/自然cleanup；逐mutant101、预定目标FAILED与具体左右值断言、无setup/timeout/forced cleanup，F inverse()重判通过 |

工具原件记录Rust1.99.0 `b940084d7`、Cargo1.99.0 `5f94df478`，与当前门禁可接受的实际环境一致；未推断其他机器或Android工具身份。

## 来源与二进制完整性边界

五个source-manifest SHA256相同：`dbc6ec0a15d00cf26233c9936a8109954773fea43247e3638005f772e1488805`。实际2751文件逐hash比较通过，固定F本地工作区clean。

Full core/plugin/host分别14/7/14个baseline executable manifest条目，binary-integrity.log逐条同路径`: OK`、条目数完全一致且verdict verified:true。下载包保留的是manifest和CI执行时的检查日志，未保留这些Linux可执行文件；因此这是**远端执行时的前后完整性封存证据**，不是本review重新读取所有Linux二进制验算。不得伪称已取得这些二进制。

Native baseline及mutant的executables_before/after字典实际相等且非空，所有raw日志hash与记录一致，native summary SHA和gate所引用一致。该runner编译后清理私有targets，本review同样核验封存记录，不声称重取已清理的二进制。

HTTP7外层baseline_binary_integrity为scope outer_baseline_executables/state not_recorded/verified null；实际HTTP7编译和精确baseline/mutant执行成立，但没有外层保留的baseline executable manifest。这一已公开范围不阻断现有合同比较，也不扩张为HTTP二进制完整性通过。

## 可复核产物及仍未完成的范围

- `audit_ci.py`：独立原件审计脚本，实际运行exit0（仅读原件/本地F并写review结果，无构建）。
- `FINAL-CI-AUDIT.json`：逐分量通过结果、manifest与gate哈希、实际库存。
- `FINAL-CI-RAW-SHA256.json`：927原件SHA256索引。
- 已前置审理的B/C源代码与C诊断范围见B-REVIEW.md、C-REVIEW.md；本次原件关闭最终legacy精确source行与实际反向执行pending。

A r1因JAVA_TOOL_OPTIONS噪声被严格6行checker拒绝，不能计为GREEN；父/root报告同F r2重跑中，另reviewer负责。M03/public API冻结、设备ART/Binder/UID/权限/fsync/kill/rebind、真实模型/真实第三方plugin/生产迁移和发布仍不由这些离线Rust CI证据成立。合入后develop精确merge SHA的相应CI需父/root另核，不把F分支run冒称develop run。

本审查无审批拒绝、无未知远端写操作、未执行commit/push/merge。CI范围通过；整套范围待A最终证据。
