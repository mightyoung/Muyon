from pathlib import Path
import sys,json,hashlib,re,subprocess
ROOT=Path('/workspace/batch4/integration');BASE=Path('/workspace/batch4/evidence/ci/downloads');F='a3ee7df596b0375aa9f3e6ff4c7651efd5f778a0'
sys.path.insert(0,str(ROOT/'experiments/redesign/rust-agent-host-lab/checks'))
from full import rust,python_suite,mutations,CASES
from legacy_semantics import accepted
from http_batch import inverse
from native_mutations import oracle
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
J=lambda p:json.loads(p.read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==F
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
report={}
for c in ('core','plugin','host','native','http'):
 b=BASE/c;e=b/'combined-evidence';g=J(e/'gate-verdict.json');s=J(e/'source-manifest.json')
 assert g['source_sha']==s['source_sha']==F and g['source_tree']==s['source_tree']=='358469bad933f71eca100ef1d4833685eaa3fd3f'
 assert g['accepted'] and g['exit_code']==0 and g['source_inputs_unchanged']
 for name,digest in s['files'].items():assert H(ROOT/name)==digest,(c,name)
 text=(b/'combined-controls/classifier.log').read_text()
 assert len(re.findall(r'^test_\w+ \(',text,re.M))==37 and re.search(r'^Ran 37 tests in ',text,re.M) and re.search(r'^OK$',text,re.M)
 r={'exact_source_files':len(s['files']),'controls':37,'gate_sha256':H(e/'gate-verdict.json'),'source_manifest_sha256':H(e/'source-manifest.json')}
 if c in ('core','plugin','host'):
  v=J(e/'behavior-verdict.json');assert H(e/'behavior.log')==v['raw_sha256'];result=rust(c,(e/'behavior.log').read_text(),v['command_exit_code'],contract='combined');assert result['accepted'];r['inventory']=result['observed_tests']
  manifest=(e/'binary-sha256.txt').read_text().splitlines();verified=(e/'binary-integrity.log').read_text().splitlines()
  assert manifest and len(manifest)==len(verified)
  assert [x.split(None,1)[1].strip() for x in manifest]==[x.removesuffix(': OK') for x in verified]
  assert all(x.endswith(': OK') for x in verified) and g['baseline_binary_integrity']['verified'] is True
  r['binary_manifest_entries']=len(manifest)
 report[c]=r
core=BASE/'core/combined-evidence'
for suite in ('process','wire_process','test_harness','test_wire_harness'):
 v=J(core/(suite+'-verdict.json'));assert H(core/(suite+'.log'))==v['raw_sha256'];r=python_suite(suite,(core/(suite+'.log')).read_text(),v['command_exit_code']);assert r['accepted'];report['core'][suite]=r['observed_methods']
rows=J(core/'mutations/summary.json');assert mutations(rows,0)['accepted']
for row in rows:
 p=core/'mutations'/Path(row['log']).name; t=p.read_text();assert row['compiled'] and row['killed']
 if row['name']=='wire_preterminal_physical_effect':
  assert 'RUST_WIRE_ARGS_ACK_OBSERVED' in t and re.search(r'AssertionError: 1 != 0[^\n]*PRETERMINAL_PHYSICAL_EFFECT',t)
  assert 'FAILED (failures=1)' in t and 'MUTANT_SETUP_TIMEOUT' not in t
 else:
  assert row['returncode']==101 and row['first_failure'] in t and 'Finished' in t and 'test result: FAILED' in t
report['core']['legacy_broad']=len(rows)
precise=J(core/'legacy-precise/summary.json');assert precise['accepted'] and precise['combined_source']['source_sha']==F
for row in precise['rows']:
 b=core/'legacy-precise'/row['name'];bt=(b/'baseline.log').read_text();mt=(b/'mutant.log').read_text()
 assert H(b/'baseline.log')==row['baseline']['raw_sha256'] and H(b/'mutant.log')==row['mutant']['raw_sha256']
 assert row['baseline']['exit_code']==0 and f"test {row['test']} ... ok" in bt
 assert accepted(row,mt,row['mutant'])
report['core']['legacy_precise']=len(precise['rows']);assert len(precise['rows'])==16
nroot=BASE/'native/combined-evidence/native';n=J(nroot/'summary.json');assert n['source_sha']==F and n['accepted'] and n['source_unchanged']
assert n['source_before_sha256']==n['source_after_sha256']
for name,digest in n['source_before_sha256'].items():assert H(ROOT/name)==digest
for mutant,rows in ((False,n['baselines']),(True,n['mutants'])):
 assert len(rows)==3
 for contract,row in zip(n['contracts'],rows):
  p=nroot/(contract['name'] if mutant else '')/(contract['name']+'.log')
  assert H(p)==row['raw_sha256'] and oracle(p.read_text(),row,contract,mutant)
  assert row['executables_unchanged'] and row['executables_before_sha256']==row['executables_after_sha256'] and row['executables_before_sha256']
  for rec in row.get('compile',[]):
   p=nroot/contract['name']/Path(rec['log']).name;assert H(p)==rec['raw_sha256'] and rec['returncode']==0 and not rec['timeout'] and rec['cleanup']['natural']
for rec in n['baseline_compile']:
 assert H(nroot/Path(rec['log']).name)==rec['raw_sha256'] and rec['returncode']==0 and rec['cleanup']['natural']
assert H(nroot/'summary.json')==J(BASE/'native/combined-evidence/gate-verdict.json')['baseline_binary_integrity']['summary_sha256']
report['native']['baseline_pairs']=3;report['native']['mutants']=3
hroot=BASE/'http/combined-evidence/http';h=J(hroot/'summary.json');assert h['source_sha']==F and h['accepted'] and len(h['rows'])==7
for row in h['rows']:
 b=hroot/row['name'];br=J(b/'baseline.log.json');mr=J(b/'mutant.log.json')
 assert H(b/'baseline.log')==br['raw_sha256'] and H(b/'mutant.log')==mr['raw_sha256']==row['mutant']['raw_sha256']
 assert br['exit_code']==0 and not br['timed_out'] and not br['forced_owned_group_cleanup'] and not br['live_after_cleanup']
 assert f"test {row['target']} ... ok" in (b/'baseline.log').read_text()
 assert inverse((b/'mutant.log').read_text(),mr,row['target'],row['expected_needles'])
g=J(BASE/'http/combined-evidence/gate-verdict.json');assert g['baseline_binary_integrity']['verified'] is None and g['baseline_binary_integrity']['state']=='not_recorded'
report['http']['baseline_pairs']=7;report['http']['mutants']=7
Path('/workspace/batch4/evidence/review/FINAL-CI-AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
