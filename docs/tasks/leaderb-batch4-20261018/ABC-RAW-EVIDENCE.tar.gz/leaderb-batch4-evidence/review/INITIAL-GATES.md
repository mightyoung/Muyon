# Batch4 独立只读初审：合入边界与验收清单

审查员 /root/review；本次仅静态读取与 Git 核查，未修改源码、未提交、未运行构建/CI、未 push/merge。此报告不是 Claude 审查。

## 固定对象

- develop `0ab2c4f667681b9aacb017f8cd2eea6f576cf78e`。
- 产品基线 `d25a407830ef624802583983c0be2414bbd59dc4`，tree `829f0d3d02bd5f8cf5f57ddef27f7fa4be3341db`。
- 初审 integration HEAD `fd19f251`（完整 SHA 将最终复审记录）；相对 d25 只有 `docs/tasks/LEADERB-BATCH4-PLAN-20261018.md`，工作区 clean。
- 固定交接 `49d3f6030c4d3464d66b4b6421e5cc416aa36133:docs/tasks/LEADERB-HANDOFF-20261018-BATCH3.md`。
- Claude 只读任务定义 `ff93284bd0c3a9e22d5b239743eb5e717cbc88ad:docs/tasks/CLAUDE-CROSS-REVIEW-20261018.md`，不是 Claude 通过报告或合入授权。

## 阻断边界

1. **实验合入与正式验收不同。** `d25:docs/tasks/PLUGIN-CONTRACT-RUST-ONLY-PLAN-20261015.md:3–7` 明确 small native read experiment，非 M03/public API finalization；`:150–152` 排除真实 endpoint、Android、迁移、DDL/write/CAS/hotload。`d25:docs/tasks/PLUGIN-PUBLIC-DATA-CLOSURE-20261018.md:3–5` 也明确无 global schema/ABI/public freeze。因此 M03 未冻结不自动阻断授权范围内的隔离实验 develop 合入，但不能因组件绿色宣称 M03/生产业务/插件执行/发布验收。
2. **旧 Dart PR76 禁止合入。** `d25:docs/superpowers/plans/2026-10-15-android-rust-offline-bridge.md:15` 明示 never merge old Dart PR76；`d25:docs/tasks/PLUGIN-CONTRACT-RUST-ONLY-PLAN-20261015.md:156–157` 禁止 whole author ancestry containing paused Dart checkpoint。初审实查 develop..d25 的 `apps/`、`packages/` 无 diff；这只能证明路径未改。暂停 checkpoint `249a8205b259999d1ff88730366df7e7e860fd6d` 本地对象不存在，ancestor 查询 INVALID（Not a valid commit name），不能据此宣称已排除 ancestry；最终需由 PR76 固定 head/远端 ancestry 或明确 diff 来源另证。
3. **d25 组合本身未获旧证据认证。** 固定交接 Integration and preservation 明确 A2f 不能认证 B d25、stock gate/组合 CI 未建立；Claude任务 §1/§3 同样只列缺口。故合入需最终候选自身 formal gate、精确远端 CI 终态、同源 Android/package 与独立 code/evidence review。既有组件 review、旧 2f CI39088023844、PR85 CI39087025974、Batch3 外置 combined runners 都不是整套组合通过。
4. **设备与真实模型边界保留。** 固定交接与 Claude任务 §3：ART/Binder/UID/permissions/fsync/kill/rebind/device/emulator NOT_RUN；HTTP trusted reconstruction test-only。这些不要求无差别停实验开发，阻断对应 Android runtime/发布/真实模型声明；不可由 JVM、API24 链接、APK 静态对齐推断运行成功。
5. **历史定时失败仍须披露。** 固定交接 Fresh results and limits 记录 100ms idle 缺 helper PID、5000ms wire 总预算失败、旧宽 classifier 误杀。最终一次绿色不证明成因；C 若无证据闭合成因，需明确 unresolved。禁止扩大原预算或隐藏失败。
6. **不等待 Claude。** 固定 ff932 只定义只读独立任务，不含必须等待 Claude 方可合入条款；本批独立审查可承担当前授权所需门禁，但不冒称 Claude 审查。

## 最终候选验收清单（待执行，非本次已通过）

- 固定完整 source SHA、clean tree、父关系、develop 对照 diff、唯一集成人；所有后续修改使旧候选结果失去 whole-candidate 身份。
- B：保留原 Core107/plugin22/host48 全部 case/family，精确映射增量115/22/59；核 actual listings 而非仅 count。native3、HTTP7、legacy17 各自 baseline0、编译成功、精确目标断言与 nonzero semantic mutant；physical17 实际 ACK/PRETERMINAL_PHYSICAL_EFFECT。保留 144 negative controls 与原 gate invalid 分类；stock anchor/inventory/pin 适配不可静默绕过。
- C：不改100ms/5000ms/默认并行；核失败原件、受控比较、最小改动、deterministic 回归/反向有效性。历史失败与新结果并存。
- A：最终 exact-source Android API24 两ABI生产、JNI/generated binding 身份、强导入/ELF16KiB、shipping Service JVM4/同次durable oracle/7负对照、shipping inverse3/独立Rust13若本批实际执行则精确列出。package state163/AIDL/lint/APK六原生项字节及ZIP16KiB/zipalign/SDK声明、普通无native-input构建均绑定实际命令退出与artifact SHA。不能嫁接2f或中间SHA。
- Formal CI：最终候选自身所选 workflow 正确触发，required full/inverse jobs实际执行并 completed/success；不得把 skip、空 test 调用、其他head绿色视为通过。合入后 develop 固定 merge SHA 的相应 CI也需核终态。
- 来源封存：source、runner、baseline binary 前后 integrity；失败保留；raw archive/index 哈希与实际文件可核；产品 source SHA 与验证archive SHA 分列。
- 合入声明限实验：M03/public API、真实第三方plugin、生产memory/REMORY、真实模型/费用、设备runtime未证部分维持原状态，不把 scoped C0 抬升整套产品验收。

当前无基于本次静态初审新发现的 Critical；正式合入判定 pending 最终候选 SHA 与实际证据，非 denied。对 PR76 ancestry 的本地检查未知范围已列明。父/root可继续独立必要工作。
