# B 固定提交独立审查

对象：`6ffc4a310aaf99c5b2bc22fb1d35ba89d61e811f`（/workspace/batch4/gates HEAD已核对）。审查员 /root/review；只读源码与实际 Python 测试，无源码修改、构建、提交、push、merge；不是 Claude 审查。范围为该提交13文件增量，非最终组合或产品验收。

结论：未发现本增量中可复现的 Critical/Important 新缺陷，允许父/root继续组合与实际编译验证。Python34通过只认证分类器与现有Python控制，不认证Rust115/22/59、native3/HTTP7/legacy17或远端CI已执行。最终合入结论 pending 最终SHA与实际证据。

## 独立实际证据

在精确HEAD执行：

`python3 -B -m unittest discover -v -s experiments/redesign/rust-agent-host-lab/checks -p 'test_*.py'`

exit0，34 tests，0.592s，OK；包含旧 full/http/native/red 全部控制、新 combined 四方法、legacy精确分类144负对照。此测试本身含 real owned-watchdog 子进程控制，不能说本次零进程执行；未运行Rust编译或产品。`git diff --check 6ffc4a3^ 6ffc4a3` exit0；前后工作区clean。

逐名集合独立复算 `full.CASES` 与 `http_batch.contract()`：Core107→115（+8、删除0）、plugin22→22（+0、删除0）、host48→59（+11、删除0）。测试contract并非仅接受总数；`full.py:13–52`逐group、逐name的Counter与结果summary全部精确核验，拒绝重复、漏项、ignored、filtered、非零退出。`cases.json`未变、product默认不变，原测试未删除；`test_combined_gate.py:14–21`逐用例删除控制已实际执行通过。

## 来源与实际执行路径

以下路径均位于精确6ffc4a310aaf99c5b2bc22fb1d35ba89d61e811f：

- `.github/workflows/leaderb-combined.yml:24–60`五矩阵core/plugin/host/native/http；push checkout github.sha，dispatch checkout显式source_sha。`source_identity.py:8–14`要求小写40SHA、HEAD相等、git status空。新入口是显式合同选择，没有失败后fallback到宽松合同；历史HTTP默认8e仍保留。最终caller必须传实际候选完整SHA，不能拿本B提交替代组合SHA。
- `combined_gate.py:20–42`定位当前repo、拒绝库内target/evidence、拒绝RUST_TEST_THREADS覆盖、记录所有tracked文件hash并前后验证clean exact identity。`:34–40`实际subprocess调用full.sh/native_mutations.py/http_batch_inverses.py；不是构造通过日志。
- `full.sh:17–34`真实cargo --no-run、build与完整cargo test；core后续实际process/wire_process/test_harness/test_wire_harness，逐方法审计。末尾实际执行旧broad17与新增legacy_precise16，不是只数定义。
- `legacy_precise.py:34–42`每个16目标分别真实baseline与私有copy mutation；baseline要求exit0且精确test ok，mutant经原linux_gate.run保留exit/timeout/owned cleanup记录；`legacy_semantics.py:22–25`同时要求raw hash、exact panic target/source行/语义断言；http inverse约束101/无timeout/无forced cleanup/无live process/单失败summary。原宽classifier没有被重新包装成精确语义证据，新增精确层弥补其旧误杀边界。
- `core-agent-lab/core/mutations.py:19`仅修正stale usage的唯一注入anchor，实际源码由 wire_counters.inflight 清理usage；其他16定义与physical17 runner未改。physical17仍实际调用独立wire_process单目标并要求ACK与preterminal oracle失败，`full.py:75–77`要求acknowledged和physical_failure。
- HTTP7使用显式SHA的git archive并真实baseline/mutant逐对运行，native3沿用实际compiled exact目标与owned cleanup、二进制before/after检查。原负例代码未放宽。

## 后续验收与具体边界

1. 必须在最终组合SHA实际跑所有五分量并核原始记录，不能把本次Python34、synthetic classifier positive或Batch3运行写成Rust通过。此审查尚未执行Rust，状态NOT_RUN而非失败/拒绝。
2. `legacy_semantics.py:5–21`固定panic行列，C若修改对应test文件则应由实际失败记录证明新的位置与原语义仍一一对应；不得为获得绿色改为宽泛assertion匹配。最终SHA必须再审anchor唯一性与真实16对记录。
3. physical17当前继承旧regex也接受`PRETERMINAL_CONFIRMATION_CONSUMED`，并非本B增量削弱；最终报告如声称physical-effect敏感性，须核实际日志为`PRETERMINAL_PHYSICAL_EFFECT`且ACK真实到达，不能只信physical_failure布尔值。
4. `combined_gate.py:43–49`只在full.sh产生binary-sha256.txt时做外层baseline完整性检查；native有自身executables before/after，HTTP7属于逐mutation rebuild。不可从统一verdict里默认true的baseline_binaries_unchanged推断HTTP7完成同类二进制前后检验。建议最终证据按各runner实际字段说明，属于准确性提示，不作为新合入阻断。
5. workflow只自动覆盖lab分支，不自动覆盖develop。父/root需要另外选择并确认合入后develop精确merge SHA的相应CI；push前B级审查不认证远端job实际触发、未skip或成功。

本次未遇自动审批拒绝；没有需要重试的受阻操作。父/root可继续集成，待最终SHA做增量复审。

## 增量复审：baff37a0 / integration e8091e5a

固定B修订 `baff37a0acd001d472a592d5ac2734781299e456`；父集成 `e8091e5a88d604bd25a3fba11260256cbd1c2b6d`（实际HEAD）。复审3文件diff：combined_gate.py、test_combined_gate.py、COMBINED-GATE.md。

原先二进制字段的准确性提示已修复：full分量缺manifest明确verified:false并使accepted失败；native引用自身summary且要求accepted/3 baseline executables_unchanged；HTTP明确scope outer_baseline_executables、state not_recorded、verified:null。HTTP整体accepted仍依赖真实HTTP7命令成功及来源不变，null只表明该项未记录，不冒称verified。这是合理的证据作用域表达，没有删减原实际测试或放宽旧负例。

在e8091e5a实际重跑同一Python discovery：36 tests，0.611s，OK（新增缺manifest与真实字节篡改控制均通过）。未执行Rust或A验收，不重复A独立审查。无新增Critical/Important发现；当前可继续C组合，最终SHA仍需实际门禁。

PR76补证：独立执行 `git merge-base --is-ancestor 16df5d9a34cfb8fb6d56d1f6b753a800889a6ace d25a407830ef624802583983c0be2414bbd59dc4` 得exit1，即root已fetch的PR76当前head不是d25祖先；develop..d25的apps/packages diff独立复核为空。注意并行命令调用的整体exit1来自此git非祖先结果，不是Python失败。暂停历史oracle249a8205的远端upload-pack not our ref为父/root报告，本审查未重试；其精确历史对象仍未知，不用PR76当前head核查冒称恢复历史对象或证明所有历史patch均不存在。原禁止合入PR76约束继续适用最终候选。

## 最终候选增量：9ffb25ee / a3ee7df5

固定B `9ffb25ee42659ec0c392cc429e5794210bc48444`，最终组合 `a3ee7df596b0375aa9f3e6ff4c7651efd5f778a0`。两文件增量仅将wire.rs五个panic行号与C插入对齐，断言语义字节和列不变；新增控制拒绝所有五个旧位置，未放宽为通配符。最终Python discovery实跑37 tests/0.604s/OK。C测试改变只增行数，原五断言对应行已静态核。最终真正legacy16失败位置/语义仍待正式gate原件，不由synthetic positive冒称实际mutant已跑。本增量无新Critical/Important发现。
