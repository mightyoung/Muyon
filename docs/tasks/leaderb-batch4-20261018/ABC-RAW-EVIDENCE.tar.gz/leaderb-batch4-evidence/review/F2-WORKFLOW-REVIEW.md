# F2 Android PR selector：独立最小增量复审

结论：**scope C0，最小修订可继续实际CI验收；无Critical/Important发现。** 这不是F2正式CI/Android/package通过报告；新head全部同源证据仍待实际执行与复审。

固定F `a3ee7df596b0375aa9f3e6ff4c7651efd5f778a0` → F2 `3f1be180bb009a91e659c113ba5b1916e5360332`。作者修订1dd8b699由父/root cherry-pick形成F2；独立git diff证实只有 `.github/workflows/android-rust-bridge.yml`、`experiments/redesign/android-rust-bridge-lab/checks/test_workflow_selection.py` 两文件，没有产品、预算、负例、Android API或其他workflow变化。

## 原始失败保留

独立读 `/workspace/batch4/evidence/ci/pr86-initial/android-rust-run.json` 与 `android-rust-jobs.json`：旧F精确head，run39096993325，event pull_request，completed/failure。select、required-linux、required-android、compiling-red和service-host-checkpoint全skipped；required-full进入并在Require every full producer to complete successfully步骤failure，后续checkout/producer downloads/APK步骤skipped，上传空产物步骤另失败。这里只取得run/job/step API原件，没有伪称读取到缺失的step stdout。

旧F `.github/workflows/android-rust-bridge.yml:40`的select job if仅允许head_ref前缀lab/android-rust-bridge-的PR，因此排除了本combined分支；原required-full fail-closed聚合将被skip的producer判失败。这是实际workflow selection缺陷，不能把初次失败说成产品通过或无关略过。

## 修订与失败传播

F2 select去掉job级if，始终执行实际inline Python。scope只允许原Android前缀或**精确等于**`lab/leaderb-batch4-combined-20261018`；当前combined PR默认suite为空时得到mode full、red[]，于是required-linux及required-android双ABI实际选择，required-full应下载本run Linux/双ABI产物并执行package_gate。push filter仍只Android专用分支，combined不因该workflow新增重复push运行。

无关PR得到明确unselected且select成功；其full producers及aggregate不运行，这是已声明的scope，不是用于掩盖本combined PR失败。近似combined名不能获得full。手动dispatch和原Android前缀的suite/red/checkpoint解析旧逻辑原字节保留，原compiled RED仍要求非零failure，未改判成功。

required-full原表达式 `always() && (mode == full || select.result != success)`未变：selector error/cancel/skip都会进入fail-closed guard；full模式下任何producer failure/cancelled/skipped/空结果都拒绝，只有select/Linux/Android三个success才继续APK。未添加continue-on-error、没有把failed aggregate改成skipped；若select成功输出full而producer被skip，仍会失败。

## 独立实际控制执行

在clean F2运行：

`python3 -B -m unittest discover -v -s experiments/redesign/android-rust-bridge-lab/checks -p 'test_*.py'`

exit0，71 tests，1.211s，OK；原件 `/workspace/batch4/evidence/review/F2-ANDROID-CONTROLS.log`。

新增三个测试实际从workflow提取并执行inline selector：精确combined PR→full、不带第二个push；近似名/无关PR→unselected且selector无job if；原Android full/red/checkpoint选择不变。原test_workflow_guard实际执行workflow inline aggregate并逐SELECT/LINUX/ANDROID键替换failure/cancelled/skipped/空值，要求非零与精确ANDROID_BRIDGE_PRODUCER_REQUIRED，全部通过。静态表达式检查结合实际inline脚本控制支持失败传播，GitHub实际DAG调度仍需F2 PR run原件证明。

## 后续scope

父/root负责F2 Rust五job、Android PR生产者/package与generic CI终态，再取实际原件。旧F Rust run39096739872及A旧F通过不能直接记成F2同次执行；虽本增量不改产品，最终精确来源门禁仍由F2自己的记录成立。初次PR failure、A r1环境噪声失败继续保留，不能被后续绿色覆盖。无审批拒绝、未改源码/提交/push/merge，本review本次仅读代码/原件并执行Python控制。
