import ctypes,json,os,pathlib,shutil,subprocess,time
base=pathlib.Path('/workspace/batch4/evidence/timing')
source=pathlib.Path('/workspace/batch4/timing/experiments/redesign/core-agent-lab/core')
copy=base/'cleanup-mutant-core'
shutil.copytree(source,copy,ignore=shutil.ignore_patterns('__pycache__'))
p=copy/'src/wire_provider.rs';text=p.read_text();anchor='if result.is_err(){let _=child.kill();let _=child.wait();}result';assert text.count(anchor)==1
p.write_text(text.replace(anchor,'if result.is_err(){}result'))
# Adopt and reap the deliberately leaked mutant helper after its owned test
# process group kills it. This wrapper is only a negative-control harness.
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
env=dict(os.environ,PATH='/workspace/batch4/tools/android/cargo/bin:'+os.environ['PATH'],CARGO_HOME='/workspace/batch4/tools/android/cargo',RUSTUP_HOME='/workspace/batch4/tools/android/rustup',CARGO_TARGET_DIR=str(base/'cleanup-mutant-target'))
command=['cargo','+1.99.0','test','--manifest-path',str(copy/'Cargo.toml'),'--test','wire','silent_and_eof_hanging_children_are_killed_and_reaped','--','--exact','--nocapture']
with (base/'cleanup-inverse.log').open('w') as log:result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
reaped=[];deadline=time.monotonic()+3
while True:
 try:pid,status=os.waitpid(-1,os.WNOHANG)
 except ChildProcessError:break
 if pid:reaped.append({'pid':pid,'status':status})
 else:
  assert time.monotonic()<deadline,'mutant descendant remained live'
  time.sleep(.01)
raw=(base/'cleanup-inverse.log').read_text()
record={'command':command,'exit':result.returncode,'removed_anchor':anchor,'expected_assertion':'child must be reaped','adopted_reaped':reaped}
(base/'cleanup-inverse.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
assert result.returncode==101
assert 'child must be reaped' in raw
assert len(reaped)==1
