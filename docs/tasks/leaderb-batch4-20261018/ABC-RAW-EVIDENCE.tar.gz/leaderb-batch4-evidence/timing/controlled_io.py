import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/workspace/batch4/timing')
evidence=pathlib.Path('/workspace/batch4/evidence/timing')
binary=evidence/'target/debug/muyon-core-agent-lab'
lab=root/'experiments/redesign/core-agent-lab'
records=[]
for delayed in (False,True):
 for chunk in (8192,1,7):
  case=f'io-delay-{int(delayed)}-chunk-{chunk}'
  directory=evidence/case
  start=[str(binary),'start','--dir',str(directory),'--provider','chat-sse','--wire-helper',str(lab/'fixtures/wire/fake_service.py'),'--wire-fixtures',str(lab/'fixtures/wire/scenarios/escaped-pair'),'--input','synthetic wire input','--mode','full-allow','--wire-chunk-size',str(chunk)]
  subprocess.run(start,check=True,capture_output=True)
  env=dict(os.environ)
  if delayed:env['LD_PRELOAD']=str(evidence/'fsync_delay.so')
  t=time.monotonic();result=subprocess.run([str(binary),'run','--dir',str(directory)],env=env,text=True,capture_output=True,timeout=20)
  elapsed=time.monotonic()-t
  (evidence/(case+'.log')).write_text(result.stdout+result.stderr)
  values=dict(line.split('=',1) for line in result.stdout.splitlines() if '=' in line)
  records.append(dict(case=case,exit=result.returncode,elapsed=elapsed,fields=values))
  print(json.dumps(records[-1]),flush=True)
(evidence/'controlled-io.json').write_text(json.dumps(records,indent=2)+'\n')
assert all(r['exit']==0 for r in records)
assert [r['fields']['status'] for r in records]==['completed','completed','completed','completed','failed','completed']
assert records[4]['fields']['reason']=='wire_total_timeout'
assert records[4]['fields']['effects']=='0'
assert 0 < int(records[4]['fields']['wire_received_bytes']) < 377
assert (evidence/'io-delay-1-chunk-1/wire-capture/emitted-1.sse').stat().st_size == 377
