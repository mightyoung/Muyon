# Timing workflow C outcome

Committed `7b0980b5ac66bea932a0c1028f873b25e2307054` on `lab/leaderb-batch4-timing-20261018`.
Final candidate focused verification: clean detached `a3ee7df596b0375aa9f3e6ff4c7651efd5f778a0`.

100ms PID ENOENT is a test-observation race: the deadline precedes Python startup,
which need not reach PID-file creation. Controlled150ms startup RED exit101;
synchronized real-PID/hold checkpoint GREEN, unchanged100ms idle/500ms total.
The final focused run covers normal/delayed silent+EOF holds and checkpoint-drop
cleanup. New group ownership and bounded waits prevent test-owned helpers leaking.
Product cleanup inverse exit101 has exact `child must be reaped` failure; the
negative subreaper harness actually reaped its one intentionally leaked helper.

5000ms total includes per-read/write durable charge/fsync. Three development causal
runs and final candidate causal run preserve all real fsyncs and original budgets.
Without injection8192/1/7 complete. With5ms/fsync,8192/7 complete and1 fails closed:
final331 sent/108 received of377 emitted, elapsed5.039s, zero effects, no resend,
helper reaped. This establishes an amplification mechanism, not the exact historical
scheduler/disk cause. Batch3 lacks the trace needed to close that attribution gap.
No product, durability, deadline, gate/workflow, Android or memory changes made.

Development default-parallel complete Core115, actual process26 and wire18 exit0.
These were dirty-test runs over HEAD d25, not whole-final-candidate evidence.
Final candidate minimum PID regression and causal driver each exit0; their source
hashes, command lines, runtime tree equality and retained binary identity are in
CANDIDATE-PROVENANCE.json. The release binary SHA matches the original Batch3 wire
binary. Initial RED input was reconstructed from recorded edits, not sealed at
execution; initial GREEN is superseded by the final commit/candidate regression.
Two inherited Rust1.99 FFI-signature warnings remain in host_session.rs.

All owned commands/builds finished; stopped-process-check.json is empty. No push,
main/develop merge or background writer remains. Historical precise attribution is
the only unresolved reason; final whole-candidate official gates belong to parent.

## Actual fixed-candidate release build followup

On clean F `a3ee7df596b0375aa9f3e6ff4c7651efd5f778a0`, actually executed
`cargo +1.99.0 build --offline --locked --release --manifest-path /workspace/batch4/timing/experiments/redesign/core-agent-lab/core/Cargo.toml --target-dir /workspace/batch4/evidence/timing/target`: exit0. Cargo reused valid cache (0.01s); this is an actual F build invocation, not a claim of forced recompilation. Before/after source hashes, clean tree and binary hashes agree; the output SHA remains b3624c75a99cb83bd1b53f3fec5ce7403d98b2f09043955b3806a998aea5d6d5.

The actual resulting output path then ran the causal driver into the new
`candidate-built-F/diagnostics` directory: exit0, source identity F, six cases.
Injected chunk1 failed closed at5.035s with331 sent/117 received of377 emitted,
zero effects/no resend/helper reaped. The other five controls completed.
The older candidate-io run is preserved and remains explicitly an equivalent
retained-binary experiment; the new run closes the actual F build-invocation gap.
See candidate-built-F/{before,after,build-provenance,diagnostics-provenance}.json.
No full suite was repeated. All owned writer/build processes finished again.
