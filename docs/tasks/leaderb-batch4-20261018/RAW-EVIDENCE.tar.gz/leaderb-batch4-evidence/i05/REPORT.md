# I05 本机 SIGKILL 补证

产品锚点 F2：`3f1be180bb009a91e659c113ba5b1916e5360332`。
实际执行 proof SHA：`a0ec87ba5f107b5905204ac2d5bd731d19f96503`，分支 `lab/leaderb-batch4-i05-proof-20261018`。未 merge、未 push。

只在 `#[cfg(test)] mod http_recovery_tests` 文件追加188行。其原F2测试前缀逐字节相同；其余2750个tracked文件逐文件与F2比较全部相同（metadata.json）。proof SHA只代表补证测试，不能替代whole-F2接受或正式CI结果。

## 实际结果

| 场景 | 首轮owned child PID | 父进程结果 | 原任务重开两次 | 网络 |
|---|---:|---|---|---|
| begin真实落盘后、connect前 | 33275 | SIGKILL signal=9 / returncode=-9，已wait回收 | outcome_unknown / wire_interrupted；原task+attempt不变；0发送/0接收 | 0 accept，重开0 accept |
| IO中途真实recv+charge持久化后 | 33281 | SIGKILL signal=9 / returncode=-9，已wait回收 | outcome_unknown / wire_interrupted；原task+attempt不变；312发送/83接收保持不增 | 1 accept / 1请求312B；发送响应83/174B，重开0 accept |
| 健康sibling同wrapper放行 | 33292 | exit0 | completed；answer=complete；重开model_sends=0 | 1 accept / 1请求312B；完整响应174B，重开0 accept |

第二次模块回归同样完成两个真实SIGKILL和健康对照，PID见 `regression-run/*/parent-network.log`。首轮组合测试1 passed；模块过滤回归 **7 passed、2 filtered**。未发现产品缺陷，无产品修复。

begin屏障由测试wrapper读取生产ModelGateway已写下的真实`outbound.db status=begin`后建立，仍未进入真实LoopbackEndpoint。IO屏障代理ProviderControl：先调用生产`charge(false,n)`，再读取真实task.db确认received和inflight持久化，随后阻塞。父进程分别调用Unix `Child::kill()`向自己spawn的实际PID发SIGKILL，`ExitStatusExt::signal()==Some(9)`。服务器只在127.0.0.1，父测试线程拥有listener，不启动后台server进程或writer。

这是**测试屏障确定窗口后由父进程施加的真实SIGKILL**；不声称自然随机崩溃。IO kill时子进程暂停于生产charge已返回后的测试屏障，而非声称正在内核recv系统调用内。实际HTTP交换和接收/计费来自真实生产LoopbackHttpTransport，没有合成账本。

重开直接使用各原目录的`Agent::open`与`NativeStore::open`，无initialize、无新任务、无替换ID。两次drive后重新open仍unknown；真实outbound与native原始bytes不变，model_sends=0，listener无新增accept。native.db没有新receipt或业务事实变化：这是纯问答fixture，证明本路径没有新增业务写入/重复效果，不外推至所有工具业务。

原有exit73、破坏ledger路径及journal失败测试保留；exit73依然只算受控退出，人工目录破坏仍是注入故障，其恢复原bytes行为未重称自然故障。原负例目录已复制至 `legacy-controlled-negative/`，原F2测试源码及其hash亦保留。

## 命令与退出

运行目录 `/workspace/batch4/i05`。工具变量：

```sh
export CARGO_HOME=/workspace/batch4/tools/android/cargo
export RUSTUP_HOME=/workspace/batch4/tools/android/rustup
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_TARGET_DIR=/workspace/batch4/i05-target
cargo test --manifest-path experiments/redesign/rust-agent-host-lab/core/Cargo.toml --lib loopback_real_sigkill_windows_and_healthy_sibling --no-run --offline
# exit 0; build.log (现有read/write FFI声明lint警告，不影响本次结果)
MUYON_SIGKILL_EVIDENCE=/workspace/batch4/evidence/i05/run /workspace/batch4/i05-target/debug/deps/muyon_rust_agent_host_lab-486f53ad8f574b9e --exact http_recovery_tests::loopback_real_sigkill_windows_and_healthy_sibling --nocapture
# exit 0; run.log
MUYON_SIGKILL_EVIDENCE=/workspace/batch4/evidence/i05/regression-run /workspace/batch4/i05-target/debug/deps/muyon_rust_agent_host_lab-486f53ad8f574b9e http_recovery_tests:: --nocapture --test-threads=1
# exit 0; regression.log
```

编辑阶段曾有一次Rust E0499编译错误（recovery闭包重复借用，已在proof提交前修正），一次误猜binary后缀导致不存在路径exit127（未启动child、未触发实验；随后从build.log获取准确binary再运行）。以上两次不算通过证据，未隐藏为成功。

## 原始证据

- `run/`和`regression-run/`：child stdout/stderr、父PID/信号/网络日志、request与实际发送response原bytes、原identity，以及task/outbound/native的before、after_child、after_recovery快照。
- `probe-source.rs`、`F2-original-http_recovery_tests.rs`、`proof.patch`：实际补证源码、F2原负例及test-only diff。
- `metadata.json`：proof/source/binary SHA256和2750文件F2等价结果。
- `cleanup.json`：owned child全部已消失，父进程wait回收；无listener/server/writer遗留。
- `sha256sums.txt`：全部封存原始文件hash；包含原负例原bytes hash。

无阻塞。没有改design、memorycrate、RSI、REMORY，没有模型或付费调用。
