from pathlib import Path
import json,sys,math,hashlib,collections,subprocess
B=Path('/workspace/batch4/evidence/timing-stability');R=Path('/workspace/batch4/integration');F='3f1be180bb009a91e659c113ba5b1916e5360332'
sys.path.insert(0,str(R/'experiments/redesign/rust-agent-host-lab/checks'))
from full import rust
J=lambda p:json.loads(p.read_text());H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=J(B/'FILES-SHA256.json')
for name,digest in manifest.items():assert H(B/name)==digest,name
s=J(B/'summary.json');v=J(B/'independent-validation.json');identity=J(B/'identity.json')
assert identity==s['identity'] and identity['source_sha']==F and identity['rust_test_threads']=='unset/default'
for k,p in [('binary_sha256',Path('/workspace/batch4/evidence/timing/target/release/muyon-core-agent-lab')),('probe_source_sha256',B/'io_probe.c'),('probe_binary_sha256',B/'io_probe.so'),('runner_sha256',B/'run_stability.py')]:assert H(p)==identity[k]
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==F
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
result={'manifest_files':len(manifest),'source_sha':F,'groups':{},'escaped_runs':0,'physical_subcases':0,'probe':[]}
for group in ('core','wire'):
 dirs=sorted((B/group).iterdir());assert len(dirs)==30;elapsed=[]
 for p in dirs:
  r=J(p/'result.json');assert r['exit']==0 and r['classification']=='PASS' and not r['timeout'];assert H(p/'raw.log')==r['log_sha256'];elapsed.append(r['elapsed_seconds']);assert not any('test-threads' in x for x in r['command'])
  if group=='core':assert rust('core',(p/'raw.log').read_text(),r['exit'],contract='combined')['accepted']
  else:
   assert r['command'][-1]=='test_same_raw_bytes_with_whole_byte_and_seven_byte_reads'
   summary=J(p/'physical/summary.json');assert summary['source_sha']==F and summary['methods']==1 and summary['success'] and summary['failures']==summary['errors']==0
   commands=[json.loads(x) for x in (p/'physical/commands.jsonl').read_text().splitlines()];assert len(commands)==24
   expected={(n,str(c)) for n in ('happy','unicode','escaped-pair','crlf-comments') for c in (8192,1,7)};observed=set()
   for start,run in zip(commands[::2],commands[1::2]):
    a=start['argv'];z=run['argv'];assert a[1]=='start' and z[1]=='run' and start['exit']==run['exit']==0
    directory=Path(a[a.index('--dir')+1]);assert str(directory)==z[z.index('--dir')+1]
    pair=(Path(a[a.index('--wire-fixtures')+1]).name,a[a.index('--wire-chunk-size')+1]);assert pair not in observed;observed.add(pair)
    fields=dict(x.split('=',1) for x in run['stdout'].splitlines() if '=' in x);assert fields['status']=='completed' and fields['effects']=='1'
    task=dict(x.split('\t',1) for x in (directory/'task.db').read_text().splitlines()[1:]);config=json.loads(bytes.fromhex(task['wire_config_hex']));assert config['total_ms']==5000 and config['idle_ms']==2000
    if pair==('escaped-pair','1'):result['escaped_runs']+=1;assert bytes.fromhex(fields['value_hex']).decode()=='😀'
    result['physical_subcases']+=1
   assert observed==expected
 elapsed.sort();q={'runs':30,'classifications':{'PASS':30},'p50_seconds':elapsed[14],'p95_seconds':elapsed[28],'max_seconds':elapsed[-1],'nonpass_rate':0.0}
 for key,value in q.items():assert s['groups'][group][key]==v['independently_recomputed'][group][key]==value
 result['groups'][group]=q
assert result['escaped_runs']==30 and result['physical_subcases']==360
keys=['status','effects','value_hex','answer_hex','wire_sent_bytes','wire_received_bytes','wire_total_bytes','model_calls','confirmations']
for chunk in (1,7,8192):
 p=B/f'probe/chunk-{chunk}';a=J(p/'baseline/probe-result.json');b=J(p/'enabled/probe-result.json')
 assert a['exit']==b['exit']==0 and all(a['values'][k]==b['values'][k] for k in keys)
 assert a['values']['status']=='completed' and a['values']['effects']=='1' and bytes.fromhex(a['values']['value_hex']).decode()=='😀'
 assert H(p/'baseline/run/raw.log')==a['log_sha256'] and H(p/'enabled/run/raw.log')==b['log_sha256']
 assert H(p/'enabled/events.jsonl')==b['events_sha256']
 events=[json.loads(x) for x in (p/'enabled/events.jsonl').read_text().splitlines()];ops={}
 for name in {x['op'] for x in events}:
  rows=[x for x in events if x['op']==name];times=sorted(x['ns'] for x in rows);n=len(rows)
  assert all(x['ns']>=0 and x['result']==(x['amount'] if name=='write_task_temp' else 0) for x in rows)
  ops[name]={'count':n,'p50_ms':times[math.ceil(n*.5)-1]/1e6,'p95_ms':times[math.ceil(n*.95)-1]/1e6,'max_ms':times[-1]/1e6,'total_ms':sum(times)/1e6}
 expected=next(x for x in v['probe'] if x['chunk']==chunk);assert ops==expected['operation_stats']
 sizes=[x.stat().st_size for x in (p/'enabled/task/wire-capture').iterdir() if x.name.startswith(('request-','emitted-'))];charges=sum(math.ceil(x/chunk) for x in sizes)
 saves=ops['rename_task_db']['count'];assert saves==ops['fsync_task_temp']['count']==ops['write_task_temp']['count']==charges+11
 assert ops['fsync_task_directory']['count']==saves+1
 result['probe'].append({'chunk':chunk,'charge_count':charges,'task_saves':saves,'file_fsync':ops['fsync_task_temp'],'directory_fsync_count':saves+1})
assert s['adopted_reaped']==[] and J(B/'stopped-process-check.json')==[]
pids=set(int(p.read_text().strip()) for p in B.rglob('child-*.pid'));assert all(not Path('/proc/'+str(pid)).exists() for pid in pids)
result['captured_helper_pids_absent']=len(pids)
Path('/workspace/batch4/evidence/review/TIMING-STABILITY-AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
