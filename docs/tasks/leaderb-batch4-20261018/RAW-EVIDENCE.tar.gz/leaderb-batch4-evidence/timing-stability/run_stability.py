import concurrent.futures,ctypes,hashlib,json,math,os,pathlib,re,signal,subprocess,time
BASE=pathlib.Path('/workspace/batch4/evidence/timing-stability');REPO=pathlib.Path('/workspace/batch4/timing');LAB=REPO/'experiments/redesign/core-agent-lab';TARGET=pathlib.Path('/workspace/batch4/evidence/timing/target');BINARY=TARGET/'release/muyon-core-agent-lab'
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
assert subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()=='3f1be180bb009a91e659c113ba5b1916e5360332'
assert not subprocess.check_output(['git','-C',str(REPO),'status','--porcelain'],text=True)
assert 'RUST_TEST_THREADS' not in os.environ
ENV=dict(os.environ,PATH='/workspace/batch4/tools/android/cargo/bin:'+os.environ['PATH'],CARGO_HOME='/workspace/batch4/tools/android/cargo',RUSTUP_HOME='/workspace/batch4/tools/android/rustup')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load():
 return {'loadavg':os.getloadavg(),'cpu_count':os.cpu_count(),'uptime':pathlib.Path('/proc/uptime').read_text().strip(),'cpu_stat':pathlib.Path('/proc/stat').read_text().splitlines()[0],'io_pressure':pathlib.Path('/proc/pressure/io').read_text() if pathlib.Path('/proc/pressure/io').exists() else None}
def descendants(pid):
 result=[]
 try:children=pathlib.Path(f'/proc/{pid}/task/{pid}/children').read_text().split()
 except FileNotFoundError:return result
 for child in children:result+=descendants(int(child))+[int(child)]
 return result
def run(command,directory,timeout=60,env=None):
 directory.mkdir(parents=True,exist_ok=True);before=load();t=time.monotonic();timedout=False
 with (directory/'raw.log').open('w') as log:
  process=subprocess.Popen(list(map(str,command)),cwd=REPO,env=env or ENV,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=process.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   timedout=True
   for pid in descendants(process.pid):
    try:os.kill(pid,signal.SIGKILL)
    except ProcessLookupError:pass
   try:os.killpg(process.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   code=process.wait(timeout=5)
 elapsed=time.monotonic()-t;raw=(directory/'raw.log').read_text()
 classification='PASS' if code==0 else ('TIMEOUT' if timedout else 'BUILD_ERROR' if 'could not compile' in raw or 'error[E' in raw else 'TEST_FAILURE' if 'FAILED' in raw else 'OTHER_EXIT')
 result={'command':list(map(str,command)),'cwd':str(REPO),'exit':code,'elapsed_seconds':elapsed,'classification':classification,'timeout':timedout,'load_before':before,'load_after':load(),'log_sha256':digest(directory/'raw.log')}
 (directory/'result.json').write_text(json.dumps(result,indent=2)+'\n');return result
identity={'source_sha':subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip(),'tree':subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD^{tree}'],text=True).strip(),'binary_sha256':digest(BINARY),'rust_test_threads':'unset/default','scope':'Thirty whole Core115 default-parallel runs plus thirty actual physical named-method runs (four scenarios x three chunks, includes escaped-pair/read_bound1). Independent groups run concurrently; no product/budget/thread changes. Probe uses real I/O without delay.','probe_source_sha256':digest(BASE/'io_probe.c'),'probe_binary_sha256':digest(BASE/'io_probe.so'),'runner_sha256':digest(pathlib.Path(__file__))}
(BASE/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
def core_runs():
 results=[]
 for n in range(1,31):
  r=run(['cargo','+1.99.0','test','--offline','--locked','--manifest-path',LAB/'core/Cargo.toml','--target-dir',TARGET],BASE/f'core/{n:02}')
  raw=(BASE/f'core/{n:02}/raw.log').read_text();counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed;',raw)
  r['observed_passed']=sum(int(a) for a,b in counts)
  if r['classification']=='PASS' and (r['observed_passed']!=115 or any(int(b) for a,b in counts)):r['classification']='INVALID_INVENTORY'
  (BASE/f'core/{n:02}/result.json').write_text(json.dumps(r,indent=2)+'\n');results.append(r);print(f'core {n}/30 {r["classification"]} {r["elapsed_seconds"]:.3f}s',flush=True)
 return results
def wire_runs():
 results=[]
 for n in range(1,31):
  directory=BASE/f'wire/{n:02}'
  r=run(['python3',LAB/'checks/wire_process.py','--binary',BINARY,'--evidence-dir',directory/'physical','--test-name','test_same_raw_bytes_with_whole_byte_and_seven_byte_reads'],directory)
  summary=directory/'physical/summary.json'
  if r['classification']=='PASS' and (not summary.exists() or json.loads(summary.read_text())['methods']!=1):r['classification']='INVALID_INVENTORY'
  (directory/'result.json').write_text(json.dumps(r,indent=2)+'\n');results.append(r);print(f'wire {n}/30 {r["classification"]} {r["elapsed_seconds"]:.3f}s',flush=True)
 return results
def probes():
 records=[]
 for chunk in (1,7,8192):
  siblings=[]
  for enabled in (False,True):
   directory=BASE/f'probe/chunk-{chunk}/{"enabled" if enabled else "baseline"}';directory.mkdir(parents=True);task=directory/'task'
   start=[BINARY,'start','--dir',task,'--provider','chat-sse','--wire-helper',LAB/'fixtures/wire/fake_service.py','--wire-fixtures',LAB/'fixtures/wire/scenarios/escaped-pair','--input','synthetic wire input','--mode','full-allow','--wire-chunk-size',str(chunk),'--wire-total-ms','5000','--wire-idle-ms','2000']
   s=run(start,directory/'start');assert s['classification']=='PASS'
   env=dict(ENV)
   if enabled:env.update(LD_PRELOAD=str(BASE/'io_probe.so'),TIMING_PROBE_TASK=str(task),TIMING_PROBE_LOG=str(directory/'events.jsonl'))
   r=run([BINARY,'run','--dir',task],directory/'run',env=env)
   values=dict(line.split('=',1) for line in (directory/'run/raw.log').read_text().splitlines() if '=' in line)
   r['values']=values;r['chunk']=chunk;r['probe_enabled']=enabled
   assert r['classification']=='PASS' and values['status']=='completed' and values['effects']=='1'
   assert bytes.fromhex(values['value_hex']).decode()=='😀'
   assert json.loads(bytes.fromhex(values['answer_hex']))=={'receipt':'r-i-1','value':'😀'}
   if enabled:
    events=[json.loads(line) for line in (directory/'events.jsonl').read_text().splitlines()];r['events_sha256']=digest(directory/'events.jsonl');stats={}
    for op in sorted({e['op'] for e in events}):
     selected=[e for e in events if e['op']==op];durations=sorted(e['ns'] for e in selected)
     stats[op]={'count':len(selected),'total_ns':sum(durations),'min_ns':durations[0],'p50_ns':durations[math.ceil(len(durations)*.50)-1],'p95_ns':durations[math.ceil(len(durations)*.95)-1],'max_ns':durations[-1],'failures':sum(e['result']<0 for e in selected),'requested_bytes':sum(e['amount'] for e in selected),'actual_write_bytes':sum(max(e['result'],0) for e in selected) if op=='write_task_temp' else None}
    r['operations']=stats
    assert {'fsync_task_temp','fsync_task_directory','write_task_temp','rename_task_db'}<=stats.keys()
    assert stats['fsync_task_temp']['count']==stats['rename_task_db']['count']
    assert all(s['failures']==0 for s in stats.values())
   siblings.append(r);records.append(r);(directory/'probe-result.json').write_text(json.dumps(r,indent=2)+'\n')
  keys=['status','effects','value_hex','answer_hex','wire_sent_bytes','wire_received_bytes','wire_total_bytes','model_calls','confirmations']
  assert all(siblings[0]['values'][k]==siblings[1]['values'][k] for k in keys)
  print(f'probe chunk {chunk}: baseline/probed physical outputs equal',flush=True)
 (BASE/'probe-results.json').write_text(json.dumps(records,indent=2)+'\n');return records
started=time.monotonic()
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 jobs={name:pool.submit(fn) for name,fn in [('core',core_runs),('wire',wire_runs),('probe',probes)]}
 results={name:job.result() for name,job in jobs.items()}
reaped=[]
while True:
 try:pid,status=os.waitpid(-1,os.WNOHANG)
 except ChildProcessError:break
 if not pid:raise AssertionError('unexpected live adopted descendant')
 reaped.append({'pid':pid,'status':status})
summary={'identity':identity,'elapsed_seconds':time.monotonic()-started,'adopted_reaped':reaped,'groups':{}}
for name in ('core','wire'):
 values=results[name];times=sorted(v['elapsed_seconds'] for v in values);classes={c:sum(r['classification']==c for r in values) for c in sorted({r['classification'] for r in values})}
 summary['groups'][name]={'runs':len(values),'classifications':classes,'nonpass_rate':sum(r['classification']!='PASS' for r in values)/len(values),'p50_seconds':times[math.ceil(len(times)*.50)-1],'p95_seconds':times[math.ceil(len(times)*.95)-1],'max_seconds':max(times),'quantile_method':'nearest-rank over all attempts; timeouts/build errors included in elapsed but classified separately','elapsed_all':times}
summary['probe']=results['probe'];(BASE/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'elapsed':summary['elapsed_seconds'],'groups':summary['groups']}),flush=True)
