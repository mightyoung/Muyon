import collections,hashlib,json,math,pathlib,subprocess
BASE=pathlib.Path('/workspace/batch4/evidence/timing-stability');REPO=pathlib.Path('/workspace/batch4/timing')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
summary=json.loads((BASE/'summary.json').read_text());independent={};targets=[]
for group in ['core','wire']:
 records=[json.loads(p.read_text()) for p in sorted((BASE/group).glob('*/result.json'))]
 assert len(records)==30
 times=sorted(r['elapsed_seconds'] for r in records);classes=dict(collections.Counter(r['classification'] for r in records))
 stats={'runs':len(records),'classifications':classes,'p50_seconds':times[14],'p95_seconds':times[28],'max_seconds':times[-1],'nonpass_rate':sum(r['classification']!='PASS' for r in records)/30}
 for key in stats:assert stats[key]==summary['groups'][group][key]
 independent[group]=stats
 if group=='core':assert all(r['observed_passed']==115 for r in records if r['classification']=='PASS')
 else:
  for iteration in sorted((BASE/group).iterdir()):
   commands=[json.loads(s) for s in (iteration/'physical/commands.jsonl').read_text().splitlines()]
   matched=[]
   for command in commands:
    argv=command['argv']
    if 'start' in argv and '--wire-fixtures' in argv and pathlib.Path(argv[argv.index('--wire-fixtures')+1]).name=='escaped-pair' and argv[argv.index('--wire-chunk-size')+1]=='1':matched.append(argv[argv.index('--dir')+1])
   assert len(matched)==1
   relevant=[c for c in commands if 'run' in c['argv'] and '--dir' in c['argv'] and c['argv'][c['argv'].index('--dir')+1]==matched[0]]
   assert relevant
   assert all(c['exit']==0 and 'status=completed\n' in c['stdout'] for c in relevant)
   targets.append({'iteration':iteration.name,'directory':matched[0],'actual_runs':len(relevant),'all_completed':True,'commands_sha256':digest(iteration/'physical/commands.jsonl')})
probes=[]
for chunk in [1,7,8192]:
 directory=BASE/f'probe/chunk-{chunk}/enabled';events=[json.loads(s) for s in (directory/'events.jsonl').read_text().splitlines()];counts=dict(collections.Counter(e['op'] for e in events));stats={}
 for op,n in counts.items():
  values=sorted(e['ns'] for e in events if e['op']==op);stats[op]={'count':n,'p50_ms':values[math.ceil(n*.50)-1]/1e6,'p95_ms':values[math.ceil(n*.95)-1]/1e6,'max_ms':max(values)/1e6,'total_ms':sum(values)/1e6};assert all(e['result']>=0 for e in events if e['op']==op)
 captures=directory/'task/wire-capture';sizes={p.name:p.stat().st_size for p in captures.iterdir() if p.name.startswith(('request-','emitted-'))};io_chunks=sum(math.ceil(n/chunk) for n in sizes.values())
 assert counts['write_task_temp']==counts['fsync_task_temp']==counts['rename_task_db']==io_chunks+11
 assert counts['fsync_task_directory']==counts['rename_task_db']+1
 probes.append({'chunk':chunk,'capture_sizes':sizes,'expected_io_chunk_charges':io_chunks,'additional_noncharge_task_saves':11,'operation_stats':stats,'scope':'File write/fsync/rename only task.db temporary files and target; directory fsync counts every fsync of this exact task directory, including one effects.db directory commit. Probe adds timing/logging overhead; no delay or altered syscall results.'})
result={'independently_recomputed':independent,'historical_exact_subcase_executions':targets,'probe':probes,'statistical_scope':'Observed rates only. Thirty finite attempts in this environment do not prove absence of flakes, and do not establish historical exact root cause. Latency quantiles are nearest-rank over whole-suite/method elapsed, not isolated escaped-pair subcase time. The two repeated cohorts ran concurrently until Core completed; source/default test thread setting unchanged.','source_sha':subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip(),'clean':not subprocess.check_output(['git','-C',str(REPO),'status','--porcelain'],text=True)}
(BASE/'independent-validation.json').write_text(json.dumps(result,indent=2)+'\n');assert result['clean'];print(json.dumps(independent,indent=2))
