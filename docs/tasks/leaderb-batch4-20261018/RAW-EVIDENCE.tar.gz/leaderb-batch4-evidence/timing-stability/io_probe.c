#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>
static _Thread_local int busy;
static long long now_ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (long long)t.tv_sec*1000000000LL+t.tv_nsec;}
static int path_kind(const char *path){const char *task=getenv("TIMING_PROBE_TASK");if(!task||!path)return 0;size_t n=strlen(task);if(strcmp(task,path)==0)return 2;if(strncmp(task,path,n)==0&&strncmp(path+n,"/.task.db.",10)==0)return 1;return 0;}
static int fd_kind(int fd){char proc[80],path[PATH_MAX];snprintf(proc,sizeof(proc),"/proc/self/fd/%d",fd);ssize_t n=readlink(proc,path,sizeof(path)-1);if(n<0)return 0;path[n]=0;return path_kind(path);}
static void record(const char *op,long long ns,long long amount,long long result){const char *path=getenv("TIMING_PROBE_LOG");if(!path)return;char line[256];int n=snprintf(line,sizeof(line),"{\"op\":\"%s\",\"ns\":%lld,\"amount\":%lld,\"result\":%lld}\n",op,ns,amount,result);int fd=syscall(SYS_openat,AT_FDCWD,path,O_WRONLY|O_CREAT|O_APPEND,0600);if(fd>=0){syscall(SYS_write,fd,line,n);syscall(SYS_close,fd);}}
int fsync(int fd){static int(*real)(int);if(!real)real=dlsym(RTLD_NEXT,"fsync");if(busy)return real(fd);busy=1;int kind=fd_kind(fd);long long t=now_ns();int r=real(fd),e=errno;if(kind)record(kind==1?"fsync_task_temp":"fsync_task_directory",now_ns()-t,0,r);busy=0;errno=e;return r;}
ssize_t write(int fd,const void *buf,size_t n){static ssize_t(*real)(int,const void*,size_t);if(!real)real=dlsym(RTLD_NEXT,"write");if(busy)return real(fd,buf,n);busy=1;int kind=fd_kind(fd);long long t=now_ns();ssize_t r=real(fd,buf,n);int e=errno;if(kind==1)record("write_task_temp",now_ns()-t,n,r);busy=0;errno=e;return r;}
int rename(const char *from,const char *to){static int(*real)(const char*,const char*);if(!real)real=dlsym(RTLD_NEXT,"rename");if(busy)return real(from,to);busy=1;const char *task=getenv("TIMING_PROBE_TASK");char target[PATH_MAX];int match=0;if(task){snprintf(target,sizeof(target),"%s/task.db",task);match=strcmp(to,target)==0&&path_kind(from)==1;}long long t=now_ns();int r=real(from,to),e=errno;if(match)record("rename_task_db",now_ns()-t,0,r);busy=0;errno=e;return r;}
