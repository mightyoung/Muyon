# Bounded exact-F2 timing stability observations

Source: `3f1be180bb009a91e659c113ba5b1916e5360332`, clean detached worktree; default Rust test threads remain unset. Runtime/source/budgets are unchanged. Actual binary SHA256: `b3624c75a99cb83bd1b53f3fec5ce7403d98b2f09043955b3806a998aea5d6d5`.

| Repeated cohort | Runs | Non-pass / attempts | p50 (s) | p95 (s) | Max (s) |
|---|---:|---:|---:|---:|---:|
| Whole Core115, default parallel | 30 | 0/30 (0.0%) | 2.223 | 2.279 | 2.279 |
| Actual physical 4-scenario × 3-chunk method | 30 | 0/30 (0.0%) | 5.029 | 5.855 | 6.256 |

Each whole-core run actually enumerated/passed115 tests. Each physical method contains12 scenario/chunk subcases; captured CLI records independently verify30 actual escaped-pair/read_bound1 executions completed. The wire latency quantiles describe the entire named method, not isolated escaped-pair latency. Quantiles use nearest rank over all attempts; build errors/timeouts are separately classified, not semantic failures. All attempts and raw logs remain, with no retries hidden.

Cohorts ran concurrently until Core finished; total orchestration elapsed 154.861s. Per-attempt loadavg, CPU counters, /proc IO pressure and uptime are retained. The cgroup resource snapshot records four CPU quota units, affinity/cpuset and memory limit. These are environment observations, not a controlled throughput benchmark. Other agents were allowed to compile independently; no Rust thread setting or budget was reduced for these runs.

## Real I/O counts, no added delay

The test-only LD_PRELOAD probe wraps real write/fsync/rename calls and records their real elapsed time/results. Its environment was applied only to each directly owned Rust run; the provider clears its helper environment. Filters count only this run's task.db temporary writes, task.db rename and fsync of the exact task directory. It neither merges/skips persistence nor changes provider admission, inflight or budget paths. Probe source, shared object, runner and hashes are retained. Every measured Rust run has an adjacent successful no-probe sibling with equal status, physical value/receipt and byte counters.

| Chunk | Task saves / atomic renames | Task-file fsyncs | Task-directory fsyncs | File-fsync p50 / p95 / max (ms) | Baseline / probed elapsed (s) |
|---:|---:|---:|---:|---|---|
| 1 | 1496 | 1496 | 1497 | 0.438 / 0.664 / 8.446 | 1.316 / 1.426 |
| 7 | 225 | 225 | 226 | 0.478 / 0.857 / 2.727 | 0.215 / 0.268 |
| 8192 | 15 | 15 | 16 | 0.694 / 3.876 / 3.876 | 0.069 / 0.115 |

All captured write/fsync/rename results succeeded. Task-save count equals actual request/response chunk charges plus11 other task saves in these runs; independent validation recomputes this from the four actual capture sizes. Directory fsync counts include one effects.db commit in the same directory, so they are not mislabeled as extra task.db saves. Each event records an individual duration; independent-validation.json gives separate per-operation distributions.

The probe performs path checks, clock reads and append logging, so its timing has observer overhead. Adjacent baseline timings do not isolate an exact overhead percentage under changing concurrent load. Only one probed/no-probe sibling per chunk was needed here; syscall distributions are individual operations within that run, not independent process repetitions.

## Limits and preserved evidence

Observed failure rate is zero in30 attempts per cohort. Finite consecutive samples in one environment do not prove zero flake probability or broad product stability. Repeated green runs and the observed persistence amplification still do not establish the exact historical disk/scheduler events: Batch3 has no such trace. Existing5ms delayed causal controls remain separately preserved in timing/candidate-built-F2; no historical evidence was overwritten or retrospectively relabeled.

No source commit, push, production change, deadline relaxation, persistence merge or thread setting change was made. Only external evidence was added. The whole process tree was bounded; no timeout occurred, and the subreaper adopted/reaped no leaked descendants. All owned build/writer processes finished; stopped-process-check.json records the final check.

Reproduction commands and per-attempt exit/elapsed/load/log hashes: core/NN/result.json and wire/NN/result.json. Main identity: identity.json; source: io_probe.c and run_stability.py; raw operation samples: probe/chunk-N/enabled/events.jsonl; independent recomputation: independent-validation.json.
