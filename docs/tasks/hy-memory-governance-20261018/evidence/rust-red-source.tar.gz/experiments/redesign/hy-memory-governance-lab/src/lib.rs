use std::path::Path;
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Error { Denied, Absent, Unknown, Conflict, InvalidSpan, Redacted, Storage }
pub type Result<T> = std::result::Result<T, Error>;
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Member { pub id: String, pub revision: i64, pub source_revision: i64, pub authority: i64, pub policy: i64, pub digest: String }
#[derive(Clone, Debug)]
pub struct Delete { pub request: String, pub member: Member, pub purpose: String }
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Job { pub sink: String, pub status: String, pub attempts: i64, pub next_retry: i64, pub operation: String }
#[derive(Clone, Copy)]
pub enum Crash { None, BeforeCommit, AfterCommit, AfterSink }
#[derive(Clone, Debug)]
pub struct Segment { pub start: usize, pub end: usize, pub replacement: Option<String> }
pub struct Lab;
impl Lab {
 pub fn open(_: &Path) -> Result<Self> { Ok(Self) }
 pub fn seed(&mut self, id: &str, _: &str) -> Result<Member> { Ok(Member { id:id.into(),revision:1,source_revision:1,authority:1,policy:1,digest:"stub".into() }) }
 pub fn current(&self, _: &str) -> Result<Member> { Err(Error::Unknown) }
 pub fn change(&mut self, _: &str, _: &str) -> Result<()> { Err(Error::Denied) }
 pub fn delete(&mut self, _: &Delete, _: Crash) -> Result<String> { Err(Error::Denied) }
 pub fn jobs(&self, _: &str) -> Result<Vec<Job>> { Ok(vec![]) }
 pub fn work(&mut self, _: &str, _: &str, _: i64, _: &str, _: Crash) -> Result<()> { Err(Error::Denied) }
 pub fn sink_exists(&self, _: &str, _: &str) -> Result<bool> { Ok(true) }
 pub fn consume(&mut self, _: &[Member]) -> Result<()> { Err(Error::Denied) }
 pub fn consumed(&self) -> Result<i64> { Ok(0) }
 pub fn quote(&mut self, _: &Member, _: &[Segment], _: bool) -> Result<String> { Err(Error::Denied) }
}
