use rusqlite::{params, Connection, OptionalExtension, TransactionBehavior};
use sha2::{Digest, Sha256};
use std::{path::Path, time::Duration};
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Error { Denied, Absent, Unknown, Conflict, InvalidSpan, Redacted, Storage }
pub type Result<T> = std::result::Result<T, Error>;
impl From<rusqlite::Error> for Error { fn from(_: rusqlite::Error) -> Self { Self::Storage } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Member { pub id: String, pub revision: i64, pub source_revision: i64, pub authority: i64, pub policy: i64, pub digest: String }
#[derive(Clone, Debug)]
pub struct Delete { pub request: String, pub member: Member, pub purpose: String }
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Job { pub sink: String, pub status: String, pub attempts: i64, pub next_retry: i64, pub operation: String }
#[derive(Clone, Copy)]
pub enum Crash { None, BeforeCommit, AfterCommit, AfterSink }
#[derive(Clone, Debug)]
pub struct Segment { pub start: usize, pub end: usize, pub replacement: Option<String> }
fn digest(s: &str) -> String { format!("{:x}", Sha256::digest(s.as_bytes())) }
pub struct Lab { db: Connection }
fn row(db: &Connection, id: &str) -> Result<(Member,String,bool)> {
 let value=db.query_row("SELECT id,revision,source_revision,authority,policy,digest,body,valid,unknown_state FROM memory WHERE id=?",[id], |r| Ok((Member{id:r.get(0)?,revision:r.get(1)?,source_revision:r.get(2)?,authority:r.get(3)?,policy:r.get(4)?,digest:r.get(5)?},r.get::<_,String>(6)?,r.get::<_,i64>(7)?,r.get::<_,i64>(8)?))).optional()?;
 let (m,body,valid,unknown)=value.ok_or(Error::Absent)?;
 if unknown!=0 { return Err(Error::Unknown); }
 Ok((m,body,valid!=0))
}
impl Lab {
 pub fn open(path: &Path) -> Result<Self> {
  let db=Connection::open(path)?; db.busy_timeout(Duration::from_secs(5))?;
  db.execute_batch("PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL;
CREATE TABLE IF NOT EXISTS memory(id TEXT PRIMARY KEY,revision INTEGER,source_revision INTEGER,authority INTEGER,policy INTEGER,digest TEXT,body TEXT,valid INTEGER DEFAULT 1,unknown_state INTEGER DEFAULT 0,automatic INTEGER DEFAULT 1,generation INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS receipts(request TEXT PRIMARY KEY,payload TEXT NOT NULL,receipt TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS jobs(request TEXT,sink TEXT,target TEXT,generation INTEGER,status TEXT,attempts INTEGER DEFAULT 0,lease INTEGER DEFAULT 0,next_retry INTEGER DEFAULT 0,operation TEXT UNIQUE,PRIMARY KEY(request,sink));
CREATE TABLE IF NOT EXISTS sinks(target TEXT,sink TEXT,PRIMARY KEY(target,sink));
CREATE TABLE IF NOT EXISTS consumed(id INTEGER PRIMARY KEY,member_count INTEGER);")?; Ok(Self{db})
 }
 pub fn seed(&mut self,id: &str,body: &str) -> Result<Member> {
  self.db.execute("INSERT INTO memory(id,revision,source_revision,authority,policy,digest,body) VALUES(?,1,1,1,1,?,?)",params![id,digest(body),body])?;
  for sink in ["vector","cache"] { self.db.execute("INSERT INTO sinks VALUES(?,?)",params![id,sink])?; }
  self.current(id)
 }
 pub fn current(&self,id: &str) -> Result<Member> { let (m,_,valid)=row(&self.db,id)?; if !valid { return Err(Error::Denied); } Ok(m) }
 /// Synthetic fixture mutation only. Every invalid condition remains fail closed.
 pub fn change(&mut self,id: &str,field: &str) -> Result<()> {
  let sql=match field {
   "revision" => "UPDATE memory SET revision=revision+1 WHERE id=?",
   "source_revision" => "UPDATE memory SET source_revision=source_revision+1 WHERE id=?",
   "authority" => "UPDATE memory SET authority=authority+1 WHERE id=?",
   "policy" => "UPDATE memory SET policy=policy+1 WHERE id=?",
   "digest" => "UPDATE memory SET digest='changed' WHERE id=?",
   "unknown" => "UPDATE memory SET unknown_state=1 WHERE id=?",
   "automatic_closed" => "UPDATE memory SET automatic=0,policy=policy+1 WHERE id=?",
   "revoked"|"tombstone"|"disabled"|"expired"|"lineage"|"scope"|"uses" => "UPDATE memory SET valid=0,generation=generation+1 WHERE id=?",
   _=>return Err(Error::Denied),
  }; self.db.execute(sql,[id])?; Ok(())
 }
 pub fn delete(&mut self, _: &Delete, _: Crash) -> Result<String> { Err(Error::Denied) }
 pub fn jobs(&self, _: &str) -> Result<Vec<Job>> { Ok(vec![]) }
 pub fn work(&mut self, _: &str, _: &str, _: i64, _: &str, _: Crash) -> Result<()> { Err(Error::Denied) }
 pub fn sink_exists(&self, _: &str, _: &str) -> Result<bool> { Ok(true) }
 pub fn consume(&mut self, _: &[Member]) -> Result<()> { Err(Error::Denied) }
 pub fn consumed(&self) -> Result<i64> { Ok(0) }
 pub fn quote(&mut self, _: &Member, _: &[Segment], _: bool) -> Result<String> { Err(Error::Denied) }
}
