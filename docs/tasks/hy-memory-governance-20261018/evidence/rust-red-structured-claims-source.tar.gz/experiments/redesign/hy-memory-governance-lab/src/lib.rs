use rusqlite::{params, Connection, OptionalExtension, TransactionBehavior};
use sha2::{Digest, Sha256};
use std::{path::Path, time::Duration};
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Error { Denied, Absent, Unknown, Conflict, InvalidSpan, Redacted, Storage }
pub type Result<T> = std::result::Result<T, Error>;
impl From<rusqlite::Error> for Error { fn from(_: rusqlite::Error) -> Self { Self::Storage } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Member { pub id: String, pub revision: i64, pub source_revision: i64, pub authority: i64, pub policy: i64, pub digest: String }
#[derive(Clone, Debug)]
pub struct Delete { pub request: String, pub member: Member, pub purpose: String }
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Job { pub sink: String, pub status: String, pub attempts: i64, pub next_retry: i64, pub operation: String }
#[derive(Clone, Copy)]
pub enum Crash { None, BeforeCommit, AfterCommit, AfterSink }
#[derive(Clone, Debug)]
pub struct Segment { pub start: usize, pub end: usize, pub replacement: Option<String> }
fn digest(s: &str) -> String { format!("{:x}", Sha256::digest(s.as_bytes())) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Quote { pub source_id: String, pub source_revision: i64, pub source_digest: String, pub segments: Vec<QuotedSegment>, pub display: String }
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct QuotedSegment { pub start: usize, pub end: usize, pub text: String, pub redacted: bool, pub reason: Option<String> }
#[derive(Clone, Debug)]
pub struct Claim { pub request: String, pub sink: String, pub target: String, pub attempt: i64, pub lease: i64 }
pub struct Lab { db: Connection }
fn row(db: &Connection, id: &str) -> Result<(Member,String,bool)> {
 let value=db.query_row("SELECT id,revision,source_revision,authority,policy,digest,body,valid,unknown_state FROM memory WHERE id=?",[id], |r| Ok((Member{id:r.get(0)?,revision:r.get(1)?,source_revision:r.get(2)?,authority:r.get(3)?,policy:r.get(4)?,digest:r.get(5)?},r.get::<_,String>(6)?,r.get::<_,i64>(7)?,r.get::<_,i64>(8)?))).optional()?;
 let (m,body,valid,unknown)=value.ok_or(Error::Absent)?;
 if unknown!=0 { return Err(Error::Unknown); }
 Ok((m,body,valid!=0))
}
impl Lab {
 pub fn open(path: &Path) -> Result<Self> {
  let db=Connection::open(path)?; db.busy_timeout(Duration::from_secs(5))?;
  db.execute_batch("PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL;
CREATE TABLE IF NOT EXISTS memory(id TEXT PRIMARY KEY,revision INTEGER,source_revision INTEGER,authority INTEGER,policy INTEGER,digest TEXT,body TEXT,valid INTEGER DEFAULT 1,unknown_state INTEGER DEFAULT 0,automatic INTEGER DEFAULT 1,generation INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS receipts(request TEXT PRIMARY KEY,payload TEXT NOT NULL,receipt TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS jobs(request TEXT,sink TEXT,target TEXT,generation INTEGER,status TEXT,attempts INTEGER DEFAULT 0,lease INTEGER DEFAULT 0,next_retry INTEGER DEFAULT 0,operation TEXT UNIQUE,PRIMARY KEY(request,sink));
CREATE TABLE IF NOT EXISTS sinks(target TEXT,sink TEXT,PRIMARY KEY(target,sink));
CREATE TABLE IF NOT EXISTS consumed(id INTEGER PRIMARY KEY,member_count INTEGER);")?; Ok(Self{db})
 }
 pub fn seed(&mut self,id: &str,body: &str) -> Result<Member> {
  self.db.execute("INSERT INTO memory(id,revision,source_revision,authority,policy,digest,body) VALUES(?,1,1,1,1,?,?)",params![id,digest(body),body])?;
  for sink in ["vector","cache"] { self.db.execute("INSERT INTO sinks VALUES(?,?)",params![id,sink])?; }
  self.current(id)
 }
 pub fn current(&self,id: &str) -> Result<Member> { let (m,_,valid)=row(&self.db,id)?; if !valid { return Err(Error::Denied); } Ok(m) }
 /// Synthetic fixture mutation only. Every invalid condition remains fail closed.
 pub fn change(&mut self,id: &str,field: &str) -> Result<()> {
  let sql=match field {
   "revision" => "UPDATE memory SET revision=revision+1 WHERE id=?",
   "source_revision" => "UPDATE memory SET source_revision=source_revision+1 WHERE id=?",
   "authority" => "UPDATE memory SET authority=authority+1 WHERE id=?",
   "policy" => "UPDATE memory SET policy=policy+1 WHERE id=?",
   "digest" => "UPDATE memory SET digest='changed' WHERE id=?",
   "unknown" => "UPDATE memory SET unknown_state=1 WHERE id=?",
   "automatic_closed" => "UPDATE memory SET automatic=0,policy=policy+1 WHERE id=?",
   "revoked"|"tombstone"|"disabled"|"expired"|"lineage"|"scope"|"uses" => "UPDATE memory SET valid=0,generation=generation+1 WHERE id=?",
   _=>return Err(Error::Denied),
  }; self.db.execute(sql,[id])?; Ok(())
 }
 pub fn delete(&mut self,d: &Delete,crash: Crash) -> Result<String> {
  // Length-delimited canonical fields prevent ambiguity and bind every input.
  let fields=[d.request.clone(),d.member.id.clone(),d.member.revision.to_string(),d.member.source_revision.to_string(),d.member.authority.to_string(),d.member.policy.to_string(),d.member.digest.clone(),d.purpose.clone()];
  let canonical:String=fields.iter().map(|f|format!("{}:{}",f.len(),f)).collect(); let payload=digest(&canonical);
  let tx=self.db.transaction_with_behavior(TransactionBehavior::Immediate)?;
  let previous=tx.query_row("SELECT payload,receipt FROM receipts WHERE request=?",[&d.request],|r|Ok((r.get::<_,String>(0)?,r.get::<_,String>(1)?))).optional()?;
  if let Some((old,receipt))=previous { return if old==payload {Ok(receipt)} else {Err(Error::Conflict)}; }
  let (current,_,valid)=row(&tx,&d.member.id)?;
  if !valid || current!=d.member || d.purpose!="manage" { return Err(Error::Denied); }
  tx.execute("UPDATE memory SET valid=0,generation=generation+1 WHERE id=?",[&d.member.id])?;
  if matches!(crash,Crash::BeforeCommit) { std::process::exit(71); }
  let generation:i64=tx.query_row("SELECT generation FROM memory WHERE id=?",[&d.member.id],|r|r.get(0))?;
  for sink in ["vector","cache"] { let op=digest(&format!("{}:{}:{}:{}",d.request,sink,d.member.id,generation)); tx.execute("INSERT INTO jobs(request,sink,target,generation,status,operation) VALUES(?,?,?,?,'pending',?)",params![d.request,sink,d.member.id,generation,op])?; }
  let receipt=format!("blocked:{}",payload); tx.execute("INSERT INTO receipts VALUES(?,?,?)",params![d.request,payload,receipt])?; tx.commit()?;
  if matches!(crash,Crash::AfterCommit) { std::process::exit(72); }
  Ok(receipt)
 }
 pub fn jobs(&self,request: &str) -> Result<Vec<Job>> {
  let mut q=self.db.prepare("SELECT sink,status,attempts,next_retry,operation FROM jobs WHERE request=? ORDER BY sink")?;
  let rows=q.query_map([request],|r|Ok(Job{sink:r.get(0)?,status:r.get(1)?,attempts:r.get(2)?,next_retry:r.get(3)?,operation:r.get(4)?}))?;
  Ok(rows.collect::<std::result::Result<Vec<_>,_>>()?)
 }
 /// `now` is a synthetic monotonic fixture clock. Outcomes simulate sink adapters.
 pub fn work(&mut self,request: &str,sink: &str,now: i64,outcome: &str,crash: Crash) -> Result<()> {
  if !["done","failed","unknown"].contains(&outcome) { return Err(Error::Denied); }
  let tx=self.db.transaction_with_behavior(TransactionBehavior::Immediate)?;
  let (target,status,lease,next):(String,String,i64,i64)=tx.query_row("SELECT target,status,lease,next_retry FROM jobs WHERE request=? AND sink=?",params![request,sink],|r|Ok((r.get(0)?,r.get(1)?,r.get(2)?,r.get(3)?)))?;
  if status=="done" { return Ok(()); }
  if (status=="claimed" && lease>now) || next>now { return Err(Error::Denied); }
  tx.execute("UPDATE jobs SET status='claimed',attempts=attempts+1,lease=? WHERE request=? AND sink=?",params![now+10,request,sink])?; tx.commit()?;
  // The target delete has its own durable commit, before outbox acknowledgement.
  if outcome=="done" { self.db.execute("DELETE FROM sinks WHERE target=? AND sink=?",params![target,sink])?; }
  if matches!(crash,Crash::AfterSink) { std::process::exit(73); }
  self.db.execute("UPDATE jobs SET status=?,lease=0,next_retry=? WHERE request=? AND sink=?",params![outcome,if outcome=="done"{0}else{now+10},request,sink])?; Ok(())
 }
 pub fn sink_exists(&self,id: &str,sink: &str) -> Result<bool> { Ok(self.db.query_row("SELECT EXISTS(SELECT 1 FROM sinks WHERE target=? AND sink=?)",params![id,sink],|r|r.get(0))?) }
 /// Final consumption and current-state checks share BEGIN IMMEDIATE with revocation.
 /// The committed synthetic record is the consumption linearization point.
 pub fn consume(&mut self,members: &[Member]) -> Result<()> {
  let tx=self.db.transaction_with_behavior(TransactionBehavior::Immediate)?;
  if members.is_empty() { return Err(Error::Denied); }
  for m in members { let (current,_,valid)=row(&tx,&m.id)?; let automatic:i64=tx.query_row("SELECT automatic FROM memory WHERE id=?",[&m.id],|r|r.get(0))?;
   if !valid || &current!=m || automatic!=1 { return Err(Error::Denied); }
  }
  tx.execute("INSERT INTO consumed(member_count) VALUES(?)",[members.len() as i64])?; tx.commit()?; Ok(())
 }
 pub fn consumed(&self) -> Result<i64> { Ok(self.db.query_row("SELECT count(*) FROM consumed",[],|r|r.get(0))?) }
 pub fn quote(&mut self,m: &Member,segments: &[Segment],continuous: bool) -> Result<Quote> {
  let tx=self.db.transaction_with_behavior(TransactionBehavior::Immediate)?;
  let (current,body,valid)=row(&tx,&m.id)?;
  if !valid || &current!=m || digest(&body)!=m.digest { return Err(Error::Denied); }
  let mut output=String::new(); let mut previous=None;
  for segment in segments {
   if segment.start>segment.end || segment.end>body.len() || !body.is_char_boundary(segment.start) || !body.is_char_boundary(segment.end) || previous.is_some_and(|end|segment.start<end) { return Err(Error::InvalidSpan); }
   if continuous && (segment.replacement.is_some() || previous.is_some_and(|end|segment.start!=end)) { return Err(Error::Redacted); }
   if let Some(replacement)=&segment.replacement { output.push_str(replacement); } else { output.push_str(&body[segment.start..segment.end]); }
   previous=Some(segment.end);
  }
  tx.commit()?; Ok(Quote{source_id:String::new(),source_revision:0,source_digest:String::new(),segments:vec![],display:output})
 }
 pub fn claim(&mut self,_request: &str,_sink: &str,_now: i64) -> Result<Option<Claim>> { Err(Error::Denied) }
 pub fn complete(&mut self,_claim: &Claim,_outcome: &str,_crash: Crash) -> Result<()> { Err(Error::Denied) }
}
